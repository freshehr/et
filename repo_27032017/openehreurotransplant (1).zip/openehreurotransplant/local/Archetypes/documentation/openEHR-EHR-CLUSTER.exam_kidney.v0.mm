<map version="1.0.1">
<!-- To view this file, download free mind mapping software FreeMind from http://freemind.sourceforge.net -->
<node BACKGROUND_COLOR="#ccccff" CREATED="1484217311114" ID="ID_1459469470" MODIFIED="1484217443381">
<richcontent TYPE="NODE"><html><head/><body><p>
<b>Exam kidney</b></p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="14"/>
<icon BUILTIN="cluster"/>
<node BACKGROUND_COLOR="#ccccff" CREATED="1484217311114" ID="ID_390273031" MODIFIED="1484217462902" POSITION="right" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>Space Occupying Lesion</b> [0..*]</p>
</body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="cluster"/>
<node BACKGROUND_COLOR="#cccccc" CREATED="1484217311114" ID="ID_1452414608" MODIFIED="1484217501655" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      <b>Space Occupying Lesion</b>
    </p>
  </body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="slot_cluster"/>
</node>
<node BACKGROUND_COLOR="#ccccff" CREATED="1484217311114" ID="ID_1764934502" MODIFIED="1484217515082" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>Location Of Space Occupying Lesion</b> [0..1]</p>
</body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="text"/>
</node>
</node>
<node BACKGROUND_COLOR="#ccccff" CREATED="1484217311130" ID="ID_371813415" MODIFIED="1484217422569" POSITION="right" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>Measurements</b> [0..1]</p>
</body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="cluster"/>
<node BACKGROUND_COLOR="#ccccff" CREATED="1484217311130" ID="ID_1385338147" MODIFIED="1484217870928" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>Thickness Of Parenchyma</b> [0..1]</p>
</body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="quantity"/>
<node CREATED="1484224215797" ID="ID_36065958" MODIFIED="1484224217709" TEXT="cm"/>
</node>
<node BACKGROUND_COLOR="#ccccff" CREATED="1484217311130" ID="ID_1010192175" MODIFIED="1484217868619" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>Height</b> [0..1]</p>
</body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="quantity"/>
<node CREATED="1484224215797" ID="ID_710196993" MODIFIED="1484224217709" TEXT="cm"/>
</node>
<node BACKGROUND_COLOR="#ccccff" CREATED="1484217311130" ID="ID_667218453" MODIFIED="1484217866045" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>Width</b> [0..1]</p>
</body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="quantity"/>
<node CREATED="1484224215797" ID="ID_1405113771" MODIFIED="1484224217709" TEXT="cm"/>
</node>
</node>
<node BACKGROUND_COLOR="#ccccff" CREATED="1484217311130" ID="ID_440827713" MODIFIED="1484735310659" POSITION="right" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>Parenchyma</b> [0..1]</p>
</body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="choice"/>
<node CREATED="1484224101141" ID="ID_1378957807" MODIFIED="1484224112749" TEXT="1. Normal size, normal parenchyma"/>
<node CREATED="1484224121797" ID="ID_941347519" MODIFIED="1484224123269" TEXT="2. Thin / atrophic parenchyma"/>
<node CREATED="1484224129949" ID="ID_378213286" MODIFIED="1484224135749" TEXT="3. Atrophic kidney"/>
<node CREATED="1484224142333" ID="ID_1238742665" MODIFIED="1484224149381" TEXT="4. Nephrectomy"/>
<node CREATED="1484224179861" ID="ID_1541596981" MODIFIED="1484224182725" TEXT="Not assessable"/>
<node CREATED="1484219986745" ID="ID_1867673725" MODIFIED="1484219993394" TEXT="Not investigated"/>
</node>
<node BACKGROUND_COLOR="#ccccff" CREATED="1484217311114" ID="ID_1103149411" MODIFIED="1484217845813" POSITION="right" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>Hydronefrosis/ Obstruction</b> [0..1]</p>
</body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="choice"/>
<node CREATED="1484224165237" ID="ID_626616150" MODIFIED="1484224168085" TEXT="Yes"/>
<node CREATED="1484224172861" ID="ID_1873072146" MODIFIED="1484224174973" TEXT="No"/>
<node CREATED="1484224179861" ID="ID_1079419157" MODIFIED="1484224182725" TEXT="Not assessable"/>
<node CREATED="1484219986745" ID="ID_1063501818" MODIFIED="1484219993394" TEXT="Not investigated"/>
</node>
<node BACKGROUND_COLOR="#ccccff" CREATED="1484217311114" ID="ID_143709605" MODIFIED="1484217804764" POSITION="right" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>Nephrolithiasis/ Renal Calculi</b> [0..1]</p>
</body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="choice"/>
<node CREATED="1484224165237" ID="ID_517190477" MODIFIED="1484224168085" TEXT="Yes"/>
<node CREATED="1484224172861" ID="ID_1126371309" MODIFIED="1484224174973" TEXT="No"/>
<node CREATED="1484224179861" ID="ID_1593726107" MODIFIED="1484224182725" TEXT="Not assessable"/>
<node CREATED="1484219986745" ID="ID_882936603" MODIFIED="1484219993394" TEXT="Not investigated"/>
</node>
</node>
</map>
