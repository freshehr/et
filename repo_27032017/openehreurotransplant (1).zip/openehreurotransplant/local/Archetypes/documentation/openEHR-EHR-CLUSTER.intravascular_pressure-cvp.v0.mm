<map version="1.0.1">
<!-- To view this file, download free mind mapping software FreeMind from http://freemind.sourceforge.net -->
<node BACKGROUND_COLOR="#ccccff" CREATED="1486039658068" ID="ID_30449469" MODIFIED="1486046806359">
<richcontent TYPE="NODE"><html><head/><body><p>
<b>Intravascular pressure cvp</b></p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="14"/>
<icon BUILTIN="cluster"/>
<node BACKGROUND_COLOR="#cccccc" CREATED="1486039658068" ID="ID_1309059415" MODIFIED="1486046796856" POSITION="right" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      <b>Location</b>
    </p>
  </body>
</html>
</richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="slot_cluster"/>
</node>
<node BACKGROUND_COLOR="#ccccff" CREATED="1486039658068" ID="ID_622646104" MODIFIED="1486046788703" POSITION="right" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>Pressure</b> [0..1]</p>
</body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="quantity"/>
<node CREATED="1486046603991" MODIFIED="1486046603991" TEXT="Digit in mmHg"/>
</node>
<node BACKGROUND_COLOR="#ccccff" CREATED="1486039658068" ID="ID_951441019" MODIFIED="1486046784039" POSITION="right" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>Relative pressure</b> [0..1]</p>
</body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="choice"/>
<node CREATED="1486046649818" ID="ID_1535973081" MODIFIED="1486046655405" TEXT="Markedly reduced"/>
<node CREATED="1486046649819" ID="ID_551650294" MODIFIED="1486046660133" TEXT="Lowered"/>
<node CREATED="1486046649821" ID="ID_1435149844" MODIFIED="1486046664365" TEXT="Normal/expected"/>
<node CREATED="1486046649821" ID="ID_268885281" MODIFIED="1486046668773" TEXT="Raised"/>
<node CREATED="1486046649822" ID="ID_1533828915" MODIFIED="1486046672885" TEXT="Markedly increased"/>
</node>
<node BACKGROUND_COLOR="#ccccff" CREATED="1486039658068" ID="ID_305451205" MODIFIED="1486046792448" POSITION="right" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>Phase of heart cycle</b> [0..1]</p>
</body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="choice"/>
<node CREATED="1486046685386" ID="ID_1273200240" MODIFIED="1486046689373" TEXT="Systolic"/>
<node CREATED="1486046685387" ID="ID_1054673794" MODIFIED="1486046693917" TEXT="Diastolic"/>
<node CREATED="1486046685387" ID="ID_1566065536" MODIFIED="1486046697733" TEXT="Pre-systolic"/>
<node CREATED="1486046685388" ID="ID_170460527" MODIFIED="1486046702133" TEXT="Pre-diastolic"/>
<node CREATED="1486046685388" ID="ID_111344938" MODIFIED="1486046706453" TEXT="Whole cycle"/>
</node>
<node BACKGROUND_COLOR="#ccccff" CREATED="1486039658068" ID="ID_533133862" MODIFIED="1486046800423" POSITION="right" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>Multimedia</b> [0..1]</p>
</body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="elemento"/>
</node>
<node BACKGROUND_COLOR="#ccccff" CREATED="1486039658068" ID="ID_1720834125" MODIFIED="1486046803543" POSITION="right" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>Comment</b> [0..1]</p>
</body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="text"/>
</node>
</node>
</map>
