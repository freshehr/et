<map version="1.0.1">
<!-- To view this file, download free mind mapping software FreeMind from http://freemind.sourceforge.net -->
<node BACKGROUND_COLOR="#ccccff" CREATED="1484216298914" ID="ID_55386928" MODIFIED="1484218031707">
<richcontent TYPE="NODE"><html><head/><body><p>
<b>Exam aorta</b></p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="14"/>
<icon BUILTIN="cluster"/>
<node BACKGROUND_COLOR="#ccccff" CREATED="1484216298914" ID="ID_772351796" MODIFIED="1484218077355" POSITION="right" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>Abnormal Morphology</b> [0..1]</p>
</body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="choice"/>
<node CREATED="1484223963717" ID="ID_100910565" MODIFIED="1484223967813" TEXT="Arteriosclerosis"/>
<node CREATED="1484223983054" ID="ID_517044682" MODIFIED="1484223986501" TEXT="Aneurysm"/>
<node CREATED="1484223993077" ID="ID_1300001641" MODIFIED="1484223996885" TEXT="Stenosis"/>
</node>
<node BACKGROUND_COLOR="#ccccff" CREATED="1484216298914" ID="ID_1127919811" MODIFIED="1484218070708" POSITION="right" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>Morphology</b> [0..1]</p>
</body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="choice"/>
<node CREATED="1484223905317" ID="ID_1616482872" MODIFIED="1484223906709" TEXT="Normal"/>
<node CREATED="1484223915613" ID="ID_95121593" MODIFIED="1484223918469" TEXT="Ab-normal"/>
<node CREATED="1484223928397" ID="ID_1103177414" MODIFIED="1484223930877" TEXT="Not assessable"/>
<node CREATED="1484219986745" ID="ID_882936603" MODIFIED="1484219993394" TEXT="Not investigated"/>
</node>
</node>
</map>
