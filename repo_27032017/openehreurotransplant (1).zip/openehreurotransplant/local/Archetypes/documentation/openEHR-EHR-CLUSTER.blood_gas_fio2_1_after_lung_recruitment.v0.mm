<map version="1.0.1">
<!-- To view this file, download free mind mapping software FreeMind from http://freemind.sourceforge.net -->
<node BACKGROUND_COLOR="#ccccff" CREATED="1486039688825" ID="ID_655964896" MODIFIED="1486045282872">
<richcontent TYPE="NODE"><html><head/><body><p>
<b>Blood gas at FIO2=1.0 after lung recruitment</b></p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="14"/>
<icon BUILTIN="cluster"/>
<node BACKGROUND_COLOR="#cccccc" CREATED="1486039688825" ID="ID_388699412" MODIFIED="1486045238857" POSITION="right" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      <b>Blood gas</b>
    </p>
  </body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="slot_cluster"/>
</node>
<node BACKGROUND_COLOR="#ccccff" CREATED="1486039688825" ID="ID_754728995" MODIFIED="1486045363109" POSITION="right" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>Suction of secretion performed</b> [0..1]</p>
</body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="choice"/>
<node CREATED="1486045214705" ID="ID_1870383649" MODIFIED="1486045214705" TEXT="Yes"/>
<node CREATED="1486045214706" ID="ID_174437728" MODIFIED="1486045214706" TEXT="No"/>
<node CREATED="1486045214706" ID="ID_383601396" MODIFIED="1486045214706" TEXT="Not possible"/>
<node CREATED="1486045220346" ID="ID_577871721" MODIFIED="1486045220346" TEXT="Not investigated"/>
</node>
<node BACKGROUND_COLOR="#ccccff" CREATED="1486039688825" ID="ID_293244670" MODIFIED="1486045357749" POSITION="right" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>Lung recruitment (back squeezing performed)</b> [0..1]</p>
</body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="choice"/>
<node CREATED="1486045214705" ID="ID_1151043636" MODIFIED="1486045214705" TEXT="Yes"/>
<node CREATED="1486045214706" ID="ID_1985744291" MODIFIED="1486045214706" TEXT="No"/>
<node CREATED="1486045214706" ID="ID_1625168686" MODIFIED="1486045214706" TEXT="Not possible"/>
<node CREATED="1486045220346" ID="ID_676423669" MODIFIED="1486045220346" TEXT="Not investigated"/>
</node>
<node BACKGROUND_COLOR="#ccccff" CREATED="1486039688825" ID="ID_103182272" MODIFIED="1486045352701" POSITION="right" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>Sample drawn after at FIO2=1.0 for 10 minutes</b> [0..1]</p>
</body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="choice"/>
<node CREATED="1486045214705" ID="ID_1914329842" MODIFIED="1486045214705" TEXT="Yes"/>
<node CREATED="1486045214706" ID="ID_241965057" MODIFIED="1486045214706" TEXT="No"/>
<node CREATED="1486045214706" ID="ID_1391072835" MODIFIED="1486045214706" TEXT="Not possible"/>
<node CREATED="1486045220346" ID="ID_1902096203" MODIFIED="1486045220346" TEXT="Not investigated"/>
</node>
</node>
</map>
