<map version="1.0.1">
<!-- To view this file, download free mind mapping software FreeMind from http://freemind.sourceforge.net -->
<node BACKGROUND_COLOR="#ccccff" CREATED="1488375391777" ID="ID_1471162374" MODIFIED="1489568743126">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Virology ET (specialized)
    </p>
  </body>
</html>
</richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="14"/>
<icon BUILTIN="cluster"/>
<node BACKGROUND_COLOR="#ccccff" CREATED="1488375391778" ID="ID_503791221" MODIFIED="1488375970502" POSITION="right" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>Laboratory result</b> [0..1]</p>
</body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="cluster"/>
<node BACKGROUND_COLOR="#ccccff" CREATED="1488375391778" ID="ID_1288495024" MODIFIED="1488375953533" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>Result Value</b> [0..1]</p>
</body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="text"/>
<node CREATED="1488375918505" ID="ID_966796123" MODIFIED="1488375926220" TEXT="Negative"/>
<node CREATED="1488375929866" ID="ID_1590831373" MODIFIED="1488375933852" TEXT="Positive"/>
</node>
<node BACKGROUND_COLOR="#ccccff" CREATED="1488375391778" ID="ID_1083297382" MODIFIED="1488375913451" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>Comment</b> [0..*]</p>
</body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="text"/>
</node>
<node BACKGROUND_COLOR="#ccccff" CREATED="1488375391778" ID="ID_1092614726" MODIFIED="1488375892611" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>Reference range guidance</b> [0..1]</p>
</body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="text"/>
</node>
<node BACKGROUND_COLOR="#ccccff" CREATED="1488375391778" ID="ID_913174750" MODIFIED="1488375850606" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>Result status</b> [0..1]</p>
</body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="text"/>
<node CREATED="1488375850598" ID="ID_258862809" MODIFIED="1488375856065" TEXT="Not Requested"/>
</node>
<node BACKGROUND_COLOR="#ccccff" CREATED="1488375391778" ID="ID_1997549559" MODIFIED="1488375799235" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>Result status timestamp</b> [0..1]</p>
</body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="datetime"/>
</node>
<node BACKGROUND_COLOR="#cccccc" CREATED="1488375391778" ID="ID_1131118925" MODIFIED="1488375771138" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      <b>Result detail</b>
    </p>
  </body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="slot"/>
</node>
</node>
<node BACKGROUND_COLOR="#cccccc" CREATED="1488375391778" ID="ID_1227496793" MODIFIED="1488375737545" POSITION="right" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      <b>Other detail</b>
    </p>
  </body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="slot"/>
</node>
</node>
</map>
