<map version="1.0.1">
<!-- To view this file, download free mind mapping software FreeMind from http://freemind.sourceforge.net -->
<node BACKGROUND_COLOR="#ccccff" CREATED="1484216246587" ID="ID_1150165539" MODIFIED="1484218867368">
<richcontent TYPE="NODE"><html><head/><body><p>
<b>Space occupying lesion</b></p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="14"/>
<icon BUILTIN="cluster"/>
<node BACKGROUND_COLOR="#ccccff" CREATED="1484216246587" ID="ID_1812693378" MODIFIED="1484218948122" POSITION="right" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>Lesion Type</b> [0..1]</p>
</body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="choice"/>
<node CREATED="1484220411565" ID="ID_1009745642" MODIFIED="1484220413141" TEXT="Tumor"/>
<node CREATED="1484220419661" ID="ID_1530042162" MODIFIED="1484220421197" TEXT="Abscess"/>
<node CREATED="1484220428069" ID="ID_1134153213" MODIFIED="1484220429909" TEXT="Angioma"/>
<node CREATED="1484220436597" ID="ID_119210888" MODIFIED="1484220438043" TEXT="Contusion"/>
<node CREATED="1484220444662" ID="ID_1380011624" MODIFIED="1484220446101" TEXT="Cyst"/>
<node CREATED="1484220452582" ID="ID_86505630" MODIFIED="1484220454918" TEXT="Not assessable"/>
<node CREATED="1484220467605" ID="ID_1687577072" MODIFIED="1484220479829" TEXT="Unspecified"/>
</node>
<node BACKGROUND_COLOR="#ccccff" CREATED="1484216246587" ID="ID_244214588" MODIFIED="1489481124532" POSITION="right" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Remarks [0..1]
    </p>
  </body>
</html>
</richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="text"/>
</node>
<node BACKGROUND_COLOR="#ccccff" CREATED="1484216246587" ID="ID_889080843" MODIFIED="1484218952634" POSITION="right" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>Space Occupying Lesion</b> [0..1]</p>
</body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="choice"/>
<node CREATED="1484220520814" ID="ID_66026536" MODIFIED="1484220523061" TEXT="Yes"/>
<node CREATED="1484220528974" ID="ID_688089422" MODIFIED="1484220531669" TEXT="No"/>
<node CREATED="1484220452582" ID="ID_444830392" MODIFIED="1484220454918" TEXT="Not assessable"/>
<node CREATED="1484219986745" ID="ID_882936603" MODIFIED="1484219993394" TEXT="Not investigated"/>
</node>
</node>
</map>
