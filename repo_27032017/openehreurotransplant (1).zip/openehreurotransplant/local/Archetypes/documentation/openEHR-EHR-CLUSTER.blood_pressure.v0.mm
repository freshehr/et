<map version="1.0.1">
<!-- To view this file, download free mind mapping software FreeMind from http://freemind.sourceforge.net -->
<node BACKGROUND_COLOR="#ccccff" CREATED="1486039867601" ID="ID_889886868" MODIFIED="1486045108152">
<richcontent TYPE="NODE"><html><head/><body><p>
<b>Blood pressure</b></p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="14"/>
<icon BUILTIN="cluster"/>
<node BACKGROUND_COLOR="#ccccff" CREATED="1486039867602" ID="ID_1917812745" MODIFIED="1486045102936" POSITION="right" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>Systolic</b> [0..1]</p>
</body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="quantity"/>
</node>
<node BACKGROUND_COLOR="#ccccff" CREATED="1486039867602" ID="ID_1359461075" MODIFIED="1486045112137" POSITION="right" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>Diastolic</b> [0..1]</p>
</body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="quantity"/>
</node>
<node BACKGROUND_COLOR="#ccccff" CREATED="1486039867602" ID="ID_1526333524" MODIFIED="1486045115905" POSITION="right" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>Mean arterial pressure</b> [0..1]</p>
</body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="quantity"/>
</node>
<node BACKGROUND_COLOR="#ccccff" CREATED="1486039867602" ID="ID_1498788455" MODIFIED="1486045118926" POSITION="right" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>Pulse pressure</b> [0..1]</p>
</body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="quantity"/>
</node>
<node BACKGROUND_COLOR="#ccccff" CREATED="1486039867602" ID="ID_228882341" MODIFIED="1486045124073" POSITION="right" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>Comment</b> [0..1]</p>
</body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="text"/>
</node>
</node>
</map>
