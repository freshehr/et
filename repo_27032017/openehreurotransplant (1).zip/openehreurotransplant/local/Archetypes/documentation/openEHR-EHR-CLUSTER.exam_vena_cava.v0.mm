<map version="1.0.1">
<!-- To view this file, download free mind mapping software FreeMind from http://freemind.sourceforge.net -->
<node BACKGROUND_COLOR="#ccccff" CREATED="1484216341493" ID="ID_1159871986" MODIFIED="1484216921669">
<richcontent TYPE="NODE"><html><head/><body><p>
<b>Exam vena cava</b></p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="14"/>
<icon BUILTIN="cluster"/>
<node BACKGROUND_COLOR="#ccccff" CREATED="1484216341493" ID="ID_1803594713" MODIFIED="1484217010257" POSITION="right" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>Flow</b> [0..1]</p>
</body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="choice"/>
<node CREATED="1484224263981" ID="ID_1753232247" MODIFIED="1484224265301" TEXT="Yes"/>
<node CREATED="1484224274597" ID="ID_1029494288" MODIFIED="1484224276133" TEXT="No"/>
<node CREATED="1484224282349" ID="ID_1249950731" MODIFIED="1484224285029" TEXT="Volume depleted"/>
<node CREATED="1484224289190" ID="ID_360039139" MODIFIED="1484224291013" TEXT="Volume overload"/>
<node CREATED="1484224298142" ID="ID_445107150" MODIFIED="1484224299757" TEXT="Not assessable"/>
<node CREATED="1484219986745" ID="ID_882936603" MODIFIED="1484219993394" TEXT="Not investigated"/>
</node>
</node>
</map>
