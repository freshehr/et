<map version="1.0.1">
<!-- To view this file, download free mind mapping software FreeMind from http://freemind.sourceforge.net -->
<node BACKGROUND_COLOR="#ccccff" CREATED="1486377546894" ID="ID_420846370" MODIFIED="1486382048668">
<richcontent TYPE="NODE"><html><head/><body><p>
<b>Echo cardiography</b></p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="14"/>
<icon BUILTIN="cluster"/>
<node BACKGROUND_COLOR="#ccccff" CREATED="1486377546894" ID="ID_1094654687" MODIFIED="1486379053277" POSITION="right" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>Inotropes</b> [0..1]</p>
</body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="cluster"/>
<node BACKGROUND_COLOR="#ccccff" CREATED="1486377546894" ID="ID_1948590448" MODIFIED="1486384624344" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>Use</b> [0..1]</p>
</body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="choice"/>
<node CREATED="1486378969818" ID="ID_1545691144" MODIFIED="1486378980284" TEXT="Yes"/>
<node CREATED="1486378969818" ID="ID_1355620431" MODIFIED="1486378985919" TEXT="No"/>
</node>
<node BACKGROUND_COLOR="#cccccc" CREATED="1486377546894" ID="ID_627816060" MODIFIED="1486379079095" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      <b>Kind of inotropes</b>
    </p>
  </body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="slot_cluster"/>
</node>
<node BACKGROUND_COLOR="#cccccc" CREATED="1486377546894" ID="ID_77110736" MODIFIED="1486379087504" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      <b>Dosage</b>
    </p>
  </body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="slot_cluster"/>
</node>
</node>
<node BACKGROUND_COLOR="#ccccff" CREATED="1486377546894" ID="ID_1104795564" MODIFIED="1486379654250" POSITION="right" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>Type of examination</b> [0..1]</p>
</body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="choice"/>
<node CREATED="1486379102724" ID="ID_1848823347" MODIFIED="1486379241035" TEXT="TTE (trans-thoracic)"/>
<node CREATED="1486379102724" ID="ID_1950552975" MODIFIED="1486379245504" TEXT="TEE (trans-oesophagal)"/>
</node>
<node BACKGROUND_COLOR="#ccccff" CREATED="1486377546894" ID="ID_1646906298" MODIFIED="1486379254292" POSITION="right" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>IVSd. (intraventricular septum diastolic thickness)</b> [0..1]</p>
</body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="quantity"/>
</node>
<node BACKGROUND_COLOR="#ccccff" CREATED="1486377546894" ID="ID_648341929" MODIFIED="1486379283444" POSITION="right" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>IVSs. (intraventricular septum systolic thickness)</b> [0..1]</p>
</body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="quantity"/>
</node>
<node BACKGROUND_COLOR="#ccccff" CREATED="1486377546894" ID="ID_1191210618" MODIFIED="1486379665957" POSITION="right" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>Visualisation ultrasound</b> [0..1]</p>
</body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="choice"/>
<node CREATED="1486379360417" ID="ID_1452400516" MODIFIED="1486379360417" TEXT="Normal"/>
<node CREATED="1486379360418" ID="ID_273522801" MODIFIED="1486379360418" TEXT="Limited"/>
<node CREATED="1486379360418" ID="ID_75315569" MODIFIED="1486379360418" TEXT="Severly Limited"/>
</node>
<node BACKGROUND_COLOR="#ccccff" CREATED="1486377546894" ID="ID_1662004571" MODIFIED="1486379597561" POSITION="right" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>Aortic annulus (root)</b> [0..1]</p>
</body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="quantity"/>
</node>
<node BACKGROUND_COLOR="#ccccff" CREATED="1486377546894" ID="ID_1355746393" MODIFIED="1486379622179" POSITION="right" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>Ascending aorta</b> [0..1]</p>
</body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="quantity"/>
</node>
<node BACKGROUND_COLOR="#ccccff" CREATED="1486377546894" ID="ID_893781827" MODIFIED="1486379691305" POSITION="right" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>Morphology of aorta</b> [0..1]</p>
</body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="text"/>
</node>
<node BACKGROUND_COLOR="#ccccff" CREATED="1486377546894" ID="ID_1389888696" MODIFIED="1489404733543" POSITION="right" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>Pericardial</b> [0..1]</p>
</body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="cluster"/>
<node BACKGROUND_COLOR="#ccccff" CREATED="1486377546894" ID="ID_1379167854" MODIFIED="1489404786121" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Pericardial effusion&#160;[0..1]
    </p>
  </body>
</html>
</richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="choice"/>
<node CREATED="1489404790251" ID="ID_496087250" MODIFIED="1489404797685" TEXT="Yes"/>
<node CREATED="1489404790267" ID="ID_715373556" MODIFIED="1489404802123" TEXT="No"/>
<node CREATED="1489404790267" ID="ID_131623062" MODIFIED="1489404806667" TEXT="Not assessable"/>
<node CREATED="1489404790267" ID="ID_164068734" MODIFIED="1489404811553" TEXT="Not investigated"/>
</node>
<node BACKGROUND_COLOR="#ccccff" CREATED="1486377546894" ID="ID_1593859527" MODIFIED="1486379848328" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>Thickness</b> [0..1]</p>
</body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="quantity"/>
</node>
</node>
<node BACKGROUND_COLOR="#ccccff" CREATED="1486377546894" ID="ID_276835955" MODIFIED="1486379933397" POSITION="right" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>Further measurements / remarks (e.g. suspicion of endocarditis, malformations (ASD/VSD))</b> [0..1]</p>
</body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="text"/>
</node>
<node BACKGROUND_COLOR="#ccccff" CREATED="1486377546894" ID="ID_996501642" MODIFIED="1486381839291" POSITION="right" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>Left</b> [0..1]</p>
</body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="cluster"/>
<node BACKGROUND_COLOR="#ccccff" CREATED="1486377546895" ID="ID_381162109" MODIFIED="1486381805476" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>LA (left artrium diameter)</b> [0..1]</p>
</body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="quantity"/>
</node>
<node BACKGROUND_COLOR="#ccccff" CREATED="1486377546895" ID="ID_624346693" MODIFIED="1486381809476" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>LV-EDD (Left ventricle end diastolic diameter)</b> [0..1]</p>
</body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="quantity"/>
</node>
<node BACKGROUND_COLOR="#ccccff" CREATED="1486377546895" ID="ID_960688386" MODIFIED="1486381813124" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>LV-ESD (Left ventricle end systolic diameter)</b> [0..1]</p>
</body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="quantity"/>
</node>
<node BACKGROUND_COLOR="#ccccff" CREATED="1486377546895" ID="ID_1455978558" MODIFIED="1486381816668" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>LVPWd (Left ventricle posterior wall diastolic thickness)</b> [0..1]</p>
</body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="quantity"/>
</node>
<node BACKGROUND_COLOR="#ccccff" CREATED="1486377546895" ID="ID_302500077" MODIFIED="1486381820172" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>LVPWs (Left ventricle posterior wall systolic thickness)</b> [0..1]</p>
</body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="quantity"/>
</node>
<node BACKGROUND_COLOR="#ccccff" CREATED="1486377546895" ID="ID_852506017" MODIFIED="1486381823708" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>LV-FS (left ventricular shortening fraction)</b> [0..1]</p>
</body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="quantity"/>
</node>
<node BACKGROUND_COLOR="#ccccff" CREATED="1486377546895" ID="ID_340626043" MODIFIED="1486381827236" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>LV-EF (Teichholz) (left ventricular ejection fraction measured by Teichholz method)</b> [0..1]</p>
</body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="quantity"/>
</node>
<node BACKGROUND_COLOR="#ccccff" CREATED="1486377546895" ID="ID_253250381" MODIFIED="1486381832356" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>LV-EF (Simpson) (left ventricular ejection fraction measeurd by Simpson method)</b> [0..1]</p>
</body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="quantity"/>
</node>
<node BACKGROUND_COLOR="#ccccff" CREATED="1486377546895" ID="ID_1310503359" MODIFIED="1486381904588" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>Regional wall motion disorders</b> [0..1]</p>
</body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="cluster"/>
<node BACKGROUND_COLOR="#ccccff" CREATED="1486377546895" ID="ID_1895543515" MODIFIED="1486381881964" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>Any Regional wall motion disorders (LV (left ventricle)</b> [0..1]</p>
</body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="choice"/>
<node CREATED="1486381571254" ID="ID_1431971790" MODIFIED="1486381571254" TEXT="Yes"/>
<node CREATED="1486381571256" ID="ID_42464748" MODIFIED="1486381571256" TEXT="No"/>
</node>
<node BACKGROUND_COLOR="#ccccff" CREATED="1486377546895" ID="ID_535379679" MODIFIED="1486381900764" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>Regional wall motion (LV (left ventricle)): Details</b> [0..1]</p>
</body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="text"/>
</node>
<node BACKGROUND_COLOR="#ccccff" CREATED="1486377546895" ID="ID_699271396" MODIFIED="1486381894068" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>Regional wall motion disorders (LV (left ventricle)): summary</b> [0..1]</p>
</body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="choice"/>
<node CREATED="1486381590631" ID="ID_1405738949" MODIFIED="1486381590631" TEXT="Regional akinesia"/>
<node CREATED="1486381590632" ID="ID_625724867" MODIFIED="1486381590632" TEXT="Hypokinesia"/>
<node CREATED="1486381590632" ID="ID_1013832584" MODIFIED="1486381590632" TEXT="Not assessable"/>
<node CREATED="1486381459923" ID="ID_732579251" MODIFIED="1486381459923" TEXT="Not investigated"/>
</node>
</node>
<node BACKGROUND_COLOR="#ccccff" CREATED="1486377546895" ID="ID_1445341190" MODIFIED="1486381846764" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>Summary LVF diastolic  (diastolic left ventricular function)</b> [0..1]</p>
</body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="choice"/>
<node CREATED="1486381437213" ID="ID_371004488" MODIFIED="1486381437213" TEXT="Normal"/>
<node CREATED="1486381437217" ID="ID_1706640725" MODIFIED="1486381437217" TEXT="Not assessable"/>
<node CREATED="1486982360133" ID="ID_567644332" MODIFIED="1486982384914" TEXT="Diastolic slightly impaired"/>
<node CREATED="1486982360133" ID="ID_1871363002" MODIFIED="1486982399912" TEXT="Diastolic dysfunction"/>
<node CREATED="1486381459923" ID="ID_1735757125" MODIFIED="1486381459923" TEXT="Not investigated"/>
</node>
<node BACKGROUND_COLOR="#ccccff" CREATED="1486377546895" ID="ID_361429264" MODIFIED="1486381854116" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>Summary LVF systolic (systolic left ventricular function)</b> [0..1]</p>
</body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="choice"/>
<node CREATED="1486381483247" ID="ID_139224918" MODIFIED="1486381483247" TEXT="Normal"/>
<node CREATED="1486381483248" ID="ID_728619779" MODIFIED="1486381483248" TEXT="Moderately reduced"/>
<node CREATED="1486381483248" ID="ID_1496112729" MODIFIED="1486381483248" TEXT="Severly reduced"/>
<node CREATED="1486381483249" ID="ID_933812820" MODIFIED="1486381483249" TEXT="Not assessable"/>
<node CREATED="1486381459923" ID="ID_30786218" MODIFIED="1486381459923" TEXT="Not investigated"/>
</node>
<node BACKGROUND_COLOR="#ccccff" CREATED="1486377546895" ID="ID_1887233569" MODIFIED="1486381866476" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>Summary LVH (left ventricular hypertrophy)</b> [0..1]</p>
</body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="choice"/>
<node CREATED="1486381533447" ID="ID_444768774" MODIFIED="1486381533447" TEXT="Normal"/>
<node CREATED="1486381533448" ID="ID_1441392787" MODIFIED="1486381533448" TEXT="Moderate"/>
<node CREATED="1486381533448" ID="ID_897407729" MODIFIED="1486381533448" TEXT="Severe"/>
<node CREATED="1486381533449" ID="ID_726979053" MODIFIED="1486381533449" TEXT="Not assessable"/>
<node CREATED="1486381459923" ID="ID_1381616751" MODIFIED="1486381459923" TEXT="Not investigated"/>
</node>
</node>
<node BACKGROUND_COLOR="#ccccff" CREATED="1486377546895" ID="ID_1803507428" MODIFIED="1486379060371" POSITION="right" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>Right</b> [0..1]</p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      <b>Right</b>
    </p>
    <p>
      <i>*</i>
    </p>
    <p>
      Type: <b>CLUSTER</b>
    </p>
    <p align="left">
      Occurences: 0..1 (optional)
    </p>
  </body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="cluster"/>
<node BACKGROUND_COLOR="#ccccff" CREATED="1486377546895" ID="ID_1009688256" MODIFIED="1486381907716" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>RV-EDD (right ventricle end diastolic diameter)</b> [0..1]</p>
</body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="quantity"/>
</node>
<node BACKGROUND_COLOR="#ccccff" CREATED="1486377546895" ID="ID_712504404" MODIFIED="1486381913700" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>RV-ESD (right ventricle end systolic diameter)</b> [0..1]</p>
</body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="quantity"/>
</node>
<node BACKGROUND_COLOR="#ccccff" CREATED="1486377546895" ID="ID_1082820869" MODIFIED="1486381918644" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>RV-TAPSE (right ventricle: Tricuspid annular plane systolic excursion)</b> [0..1]</p>
</body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="quantity"/>
</node>
<node BACKGROUND_COLOR="#ccccff" CREATED="1486377546895" ID="ID_1754176914" MODIFIED="1486381922676" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>RV-Wall (right ventricle wall thickness)</b> [0..1]</p>
</body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="quantity"/>
</node>
<node BACKGROUND_COLOR="#ccccff" CREATED="1486377546895" ID="ID_1684961986" MODIFIED="1486381926116" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>RV-Morphology (right ventricle morphology)</b> [0..1]</p>
</body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="choice"/>
<node CREATED="1486381689285" ID="ID_821270606" MODIFIED="1486381689285" TEXT="Normal"/>
<node CREATED="1486381689285" ID="ID_651370791" MODIFIED="1486381689285" TEXT="Hypertrophy"/>
<node CREATED="1486381689285" ID="ID_1987844370" MODIFIED="1486381689285" TEXT="Not assessable"/>
<node CREATED="1486381459923" ID="ID_1711857580" MODIFIED="1486381459923" TEXT="Not investigated"/>
</node>
<node BACKGROUND_COLOR="#ccccff" CREATED="1486377546895" ID="ID_600905350" MODIFIED="1486381937220" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>RV-Function (right ventricle function)</b> [0..1]</p>
</body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="choice"/>
<node CREATED="1486381742717" ID="ID_1666100146" MODIFIED="1486381742717" TEXT="Normal"/>
<node CREATED="1486381742717" ID="ID_959807561" MODIFIED="1486381742717" TEXT="Function reduced"/>
<node CREATED="1486381742717" ID="ID_1009859226" MODIFIED="1486381742717" TEXT="Not assessable"/>
<node CREATED="1486381459923" ID="ID_1228108744" MODIFIED="1486381459923" TEXT="Not investigated"/>
</node>
<node BACKGROUND_COLOR="#ccccff" CREATED="1486377546895" ID="ID_1375497657" MODIFIED="1486381952323" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>RV-Dimension (right ventricle dimension)</b> [0..1]</p>
</body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="choice"/>
<node CREATED="1486381771798" ID="ID_1556354001" MODIFIED="1486381771798" TEXT="Normal"/>
<node CREATED="1486381771799" ID="ID_1042038746" MODIFIED="1486381771799" TEXT="Moderate dilated"/>
<node CREATED="1486381771800" ID="ID_144460657" MODIFIED="1486381771800" TEXT="Dilated"/>
<node CREATED="1486381771800" ID="ID_1027242341" MODIFIED="1486381771800" TEXT="Not assessable"/>
<node CREATED="1486381459923" ID="ID_22299914" MODIFIED="1486381459923" TEXT="Not investigated"/>
</node>
</node>
<node BACKGROUND_COLOR="#cccccc" CREATED="1486377546896" ID="ID_1051232991" MODIFIED="1486546856489" POSITION="right" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      <b>Valve Condition</b>
    </p>
  </body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="slot_cluster"/>
</node>
</node>
</map>
