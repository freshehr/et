<map version="1.0.1">
<!-- To view this file, download free mind mapping software FreeMind from http://freemind.sourceforge.net -->
<node BACKGROUND_COLOR="#ccccff" CREATED="1486039722259" ID="ID_648343746" MODIFIED="1486043405624">
<richcontent TYPE="NODE"><html><head/><body><p>
<b>Ctx thorax</b></p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="14"/>
<icon BUILTIN="cluster"/>
<node BACKGROUND_COLOR="#ccccff" CREATED="1486039722259" ID="ID_1389265108" MODIFIED="1486043401022" POSITION="right" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>Trachea</b> [0..1]</p>
</body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="cluster"/>
<node BACKGROUND_COLOR="#ccccff" CREATED="1486039722259" ID="ID_1707910770" MODIFIED="1486043395464" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>Comment</b> [0..1]</p>
</body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="text"/>
</node>
<node BACKGROUND_COLOR="#ccccff" CREATED="1486039722259" ID="ID_753515801" MODIFIED="1486043378080" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>Trachea</b> [0..1]</p>
</body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="cluster"/>
<node BACKGROUND_COLOR="#ccccff" CREATED="1486039722259" ID="ID_1776319719" MODIFIED="1486043373568" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>In midline</b> [0..1]</p>
</body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="choice"/>
<node CREATED="1486043128586" MODIFIED="1486043128586" TEXT="Yes"/>
<node CREATED="1486043128587" MODIFIED="1486043128587" TEXT="No"/>
<node CREATED="1486043128588" MODIFIED="1486043128588" TEXT="Not assessable"/>
<node CREATED="1486043019900" ID="ID_991956509" MODIFIED="1489403964441" TEXT="Not investigated"/>
</node>
<node BACKGROUND_COLOR="#ccccff" CREATED="1486039722259" ID="ID_610034310" MODIFIED="1486043368336" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>ET Tube cranial to carina</b> [0..1]</p>
</body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="choice"/>
<node CREATED="1486043136643" ID="ID_10550436" MODIFIED="1486043136643" TEXT="Yes"/>
<node CREATED="1486043136644" ID="ID_727425815" MODIFIED="1486043136644" TEXT="No"/>
<node CREATED="1486043136645" ID="ID_1988424832" MODIFIED="1486043136645" TEXT="Not assessable"/>
<node CREATED="1486043019900" ID="ID_936820128" MODIFIED="1489403964441" TEXT="Not investigated"/>
</node>
</node>
</node>
<node BACKGROUND_COLOR="#cccccc" CREATED="1486039722259" ID="ID_1555956549" MODIFIED="1486043364216" POSITION="right" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      <b>Left lung</b>
    </p>
  </body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="slot_cluster"/>
</node>
<node BACKGROUND_COLOR="#cccccc" CREATED="1486039722259" ID="ID_342872553" MODIFIED="1486043355296" POSITION="right" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      <b>Right lung</b>
    </p>
  </body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="slot_cluster"/>
</node>
<node BACKGROUND_COLOR="#ccccff" CREATED="1486039722259" ID="ID_1800282588" MODIFIED="1486043284406" POSITION="right" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>Foreign body</b> [0..1]</p>
</body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="cluster"/>
<node BACKGROUND_COLOR="#ccccff" CREATED="1486039722259" ID="ID_847854979" MODIFIED="1486043270375" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>Location</b> [0..1]</p>
</body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="cluster"/>
<node BACKGROUND_COLOR="#ccccff" CREATED="1486039722259" ID="ID_1139968031" MODIFIED="1486043275241" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>Location</b> [0..1]</p>
</body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="choice"/>
<node CREATED="1486043149713" MODIFIED="1486043149713" TEXT="Left lung"/>
<node CREATED="1486043149713" MODIFIED="1486043149713" TEXT="Right lung"/>
<node CREATED="1486043149713" MODIFIED="1486043149713" TEXT="Both lungs"/>
<node CREATED="1486043149713" MODIFIED="1486043149713" TEXT="Trachea"/>
<node CREATED="1486043149713" MODIFIED="1486043149713" TEXT="No"/>
</node>
<node BACKGROUND_COLOR="#ccccff" CREATED="1486039722259" ID="ID_1102758576" MODIFIED="1486043266105" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>Specification</b> [0..1]</p>
</body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="text"/>
</node>
</node>
</node>
<node BACKGROUND_COLOR="#ccccff" CREATED="1486039722259" ID="ID_768079796" MODIFIED="1486043204097" POSITION="right" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>Comments</b> [0..1]</p>
</body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="text"/>
</node>
<node BACKGROUND_COLOR="#cccccc" CREATED="1486039722259" ID="ID_1156152674" MODIFIED="1486043200049" POSITION="right" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      <b>Recording device</b>
    </p>
  </body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="slot_cluster"/>
</node>
<node BACKGROUND_COLOR="#ccccff" CREATED="1486039722259" ID="ID_581424450" MODIFIED="1486043216945" POSITION="right" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>Heart shadow enlarged</b> [0..1]</p>
</body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="choice"/>
<node CREATED="1486043136643" ID="ID_494238845" MODIFIED="1486043136643" TEXT="Yes"/>
<node CREATED="1486043136644" ID="ID_1943177391" MODIFIED="1486043136644" TEXT="No"/>
<node CREATED="1486043136645" ID="ID_130665049" MODIFIED="1486043136645" TEXT="Not assessable"/>
<node CREATED="1486043000154" ID="ID_1912369998" MODIFIED="1486043026455" TEXT="Not investigated"/>
</node>
<node BACKGROUND_COLOR="#ccccff" CREATED="1486039722259" ID="ID_1042344072" MODIFIED="1486043885383" POSITION="right" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>Mediastinum enlarged</b> [0..1]</p>
</body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="choice"/>
<node CREATED="1486043136643" ID="ID_533538300" MODIFIED="1486043136643" TEXT="Yes"/>
<node CREATED="1486043136644" ID="ID_1208676832" MODIFIED="1486043136644" TEXT="No"/>
<node CREATED="1486043136645" ID="ID_1253676919" MODIFIED="1486043136645" TEXT="Not assessable"/>
<node CREATED="1486043006596" ID="ID_1851790286" MODIFIED="1486043032758" TEXT="Not investigated"/>
</node>
<node BACKGROUND_COLOR="#ccccff" CREATED="1486039722259" ID="ID_1279246554" MODIFIED="1486043889567" POSITION="right" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>Prominent Hilum</b> [0..1]</p>
</body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="choice"/>
<node CREATED="1486043136643" ID="ID_1876427988" MODIFIED="1486043136643" TEXT="Yes"/>
<node CREATED="1486043136644" ID="ID_436373038" MODIFIED="1486043136644" TEXT="No"/>
<node CREATED="1486043136645" ID="ID_916153642" MODIFIED="1486043136645" TEXT="Not assessable"/>
<node CREATED="1486043011969" ID="ID_488689853" MODIFIED="1486043037638" TEXT="Not investigated"/>
</node>
</node>
</map>
