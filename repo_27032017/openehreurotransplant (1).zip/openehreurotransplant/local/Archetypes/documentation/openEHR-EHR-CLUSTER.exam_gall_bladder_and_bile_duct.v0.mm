<map version="1.0.1">
<!-- To view this file, download free mind mapping software FreeMind from http://freemind.sourceforge.net -->
<node BACKGROUND_COLOR="#ccccff" CREATED="1484565140076" ID="ID_1094685106" MODIFIED="1484565282140">
<richcontent TYPE="NODE"><html><head/><body><p>
<b>Exam gall bladder and bile duct</b></p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="14"/>
<icon BUILTIN="cluster"/>
<node BACKGROUND_COLOR="#cccccc" CREATED="1484565140076" ID="ID_850188757" MODIFIED="1484565301656" POSITION="right" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      <b>Space Occupying Lesion</b>
    </p>
  </body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="slot_cluster"/>
</node>
<node BACKGROUND_COLOR="#ccccff" CREATED="1484565140076" ID="ID_457167171" MODIFIED="1484565424494" POSITION="right" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>Cholecystitis</b> [0..1]</p>
</body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="choice"/>
<node CREATED="1484566171961" ID="ID_1249250143" MODIFIED="1484566174117" TEXT="Yes"/>
<node CREATED="1484566177093" ID="ID_186794892" MODIFIED="1484566178565" TEXT="No"/>
<node CREATED="1484566182496" ID="ID_1889682109" MODIFIED="1484566195082" TEXT="Not assessable"/>
<node CREATED="1484566095194" ID="ID_309585748" MODIFIED="1484566100291" TEXT="Not investigated"/>
</node>
<node BACKGROUND_COLOR="#ccccff" CREATED="1484565140076" ID="ID_93106960" MODIFIED="1484565438585" POSITION="right" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>Cholelithiasis</b> [0..1]</p>
</body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="choice"/>
<node CREATED="1484566171961" ID="ID_778948022" MODIFIED="1484566174117" TEXT="Yes"/>
<node CREATED="1484566177093" ID="ID_1901907997" MODIFIED="1484566178565" TEXT="No"/>
<node CREATED="1484566182496" ID="ID_1093094094" MODIFIED="1484566195082" TEXT="Not assessable"/>
<node CREATED="1484566095194" ID="ID_1530105454" MODIFIED="1484566100291" TEXT="Not investigated"/>
</node>
<node BACKGROUND_COLOR="#ccccff" CREATED="1484565140076" ID="ID_145177677" MODIFIED="1484566071337" POSITION="right" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>Extrahepatic bile duct</b> [0..1]</p>
</body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="choice"/>
<node CREATED="1484566117955" ID="ID_1071787974" MODIFIED="1484566120738" TEXT="Normal"/>
<node CREATED="1484566124535" ID="ID_631422996" MODIFIED="1484566142600" TEXT="Choledocholithiasis"/>
<node CREATED="1484566149462" ID="ID_1419106002" MODIFIED="1484566155399" TEXT="Dilated"/>
<node CREATED="1484566160909" ID="ID_678809586" MODIFIED="1484566165836" TEXT="Not assessable"/>
<node CREATED="1484566095194" ID="ID_11170668" MODIFIED="1484566100291" TEXT="Not investigated"/>
</node>
</node>
</map>
