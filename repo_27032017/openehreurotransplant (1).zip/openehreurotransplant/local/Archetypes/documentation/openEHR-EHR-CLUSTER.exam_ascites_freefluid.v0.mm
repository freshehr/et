<map version="1.0.1">
<!-- To view this file, download free mind mapping software FreeMind from http://freemind.sourceforge.net -->
<node BACKGROUND_COLOR="#ccccff" CREATED="1484216364196" ID="ID_1265517657" MODIFIED="1484216821180">
<richcontent TYPE="NODE"><html><head/><body><p>
<b>Exam ascites freefluid</b></p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="14"/>
<icon BUILTIN="cluster"/>
<node BACKGROUND_COLOR="#ccccff" CREATED="1484216364196" ID="ID_954317736" MODIFIED="1484216866231" POSITION="right" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>Ascites/ free fluid</b> [0..1]</p>
</body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="choice"/>
<node CREATED="1484224332445" ID="ID_1583274701" MODIFIED="1484224334117" TEXT="Moderate"/>
<node CREATED="1484224340790" ID="ID_634672330" MODIFIED="1484224342477" TEXT="None"/>
<node CREATED="1484224350478" ID="ID_1079573603" MODIFIED="1484224351885" TEXT="Significant "/>
<node CREATED="1484224358301" ID="ID_1502202113" MODIFIED="1484224360109" TEXT="Not assessable"/>
<node CREATED="1484219986745" ID="ID_882936603" MODIFIED="1484219993394" TEXT="Not investigated"/>
</node>
</node>
</map>
