These are archetypes exported from the Clinical Knowledge Manager.
Export time: Tue Dec 06 11:01:56 CET 2016