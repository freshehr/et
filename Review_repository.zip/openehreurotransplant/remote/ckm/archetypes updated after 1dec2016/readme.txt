These are archetypes exported from the Clinical Knowledge Manager.
Export time: Fri Sep 15 15:54:06 CEST 2017