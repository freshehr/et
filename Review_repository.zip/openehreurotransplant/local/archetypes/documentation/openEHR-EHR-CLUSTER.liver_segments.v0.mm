<map version="1.0.1">
<!-- To view this file, download free mind mapping software FreeMind from http://freemind.sourceforge.net -->
<node BACKGROUND_COLOR="#ccccff" CREATED="1508152089832" ID="ID_1268363760" MODIFIED="1508153530700">
<richcontent TYPE="NODE"><html><head/><body><p>
<b>Liver segments</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Liver segments of the Liver
    </p>
  </body>
</html>
</richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="14"/>
<icon BUILTIN="cluster"/>
<node BACKGROUND_COLOR="#ccccff" CREATED="1508152089832" ID="ID_1347858869" MODIFIED="1508153583426" POSITION="right" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>Segments</b> [0..1]</p>
</body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="choice"/>
<node CREATED="1508153586647" ID="ID_1073807528" MODIFIED="1508153623875" TEXT="I"/>
<node CREATED="1508153589151" ID="ID_1468836423" MODIFIED="1508153625473" TEXT="II"/>
<node CREATED="1508153591456" ID="ID_1371293112" MODIFIED="1508153627187" TEXT="III"/>
<node CREATED="1508153593671" ID="ID_1389049949" MODIFIED="1508153635171" TEXT="IVa"/>
<node CREATED="1508153595959" ID="ID_1136393454" MODIFIED="1508153640779" TEXT="IVb"/>
<node CREATED="1508153598575" ID="ID_643288424" MODIFIED="1508153644195" TEXT="V"/>
<node CREATED="1508153601304" ID="ID_1432195765" MODIFIED="1508153646699" TEXT="VI"/>
<node CREATED="1508153603744" ID="ID_951011764" MODIFIED="1508153650293" TEXT="VII"/>
<node CREATED="1508153618785" ID="ID_969378776" MODIFIED="1508153655100" TEXT="VIII"/>
</node>
<node BACKGROUND_COLOR="#ccccff" CREATED="1508152089833" ID="ID_1101248140" MODIFIED="1508153682359" POSITION="right" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>Comment</b> [0..1]</p>
</body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="text"/>
</node>
</node>
</map>
