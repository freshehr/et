<map version="1.0.1">
<!-- To view this file, download free mind mapping software FreeMind from http://freemind.sourceforge.net -->
<node BACKGROUND_COLOR="#ccccff" CREATED="1486377503669" ID="ID_1454915608" MODIFIED="1486387474861">
<richcontent TYPE="NODE"><html><head/><body><p>
<b>Ctx pathological abnormalities bronchus</b></p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="14"/>
<icon BUILTIN="cluster"/>
<node BACKGROUND_COLOR="#ccccff" CREATED="1486377503669" ID="ID_275891634" MODIFIED="1486387453493" POSITION="right" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>Pathological abnormalities bronchus</b> [0..1]</p>
</body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="cluster"/>
<node BACKGROUND_COLOR="#ccccff" CREATED="1486377503669" ID="ID_261394318" MODIFIED="1486387447997" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>Type</b> [0..1]</p>
</body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="choice"/>
<node CREATED="1486387385152" ID="ID_1710956584" MODIFIED="1486387385152" TEXT="interstitial lung disease"/>
<node CREATED="1486387385153" ID="ID_458959787" MODIFIED="1486387385153" TEXT="Emphysema"/>
<node CREATED="1486387385154" ID="ID_701941273" MODIFIED="1486387385154" TEXT="space occupying lesion"/>
<node CREATED="1486387385154" ID="ID_398978807" MODIFIED="1486387385154" TEXT="bronchial thickening"/>
<node CREATED="1486387385154" ID="ID_1377326750" MODIFIED="1486387385154" TEXT="infiltrates"/>
<node CREATED="1486387385155" ID="ID_1284660515" MODIFIED="1486387385155" TEXT="atelectasis"/>
<node CREATED="1486387385155" ID="ID_361771702" MODIFIED="1486387385155" TEXT="pleural thickening"/>
<node CREATED="1486387385156" ID="ID_992989432" MODIFIED="1486387385156" TEXT="pleura-effusion"/>
<node CREATED="1486387385156" ID="ID_368766499" MODIFIED="1486387385156" TEXT="pneumothorax"/>
<node CREATED="1486387385157" ID="ID_514616234" MODIFIED="1486387385157" TEXT="Rib fractures"/>
</node>
<node BACKGROUND_COLOR="#ccccff" CREATED="1486377503669" ID="ID_1277683323" MODIFIED="1486387443517" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>Result</b> [0..*]</p>
</body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="choice"/>
<node CREATED="1486387395673" ID="ID_1481196524" MODIFIED="1486387395673" TEXT="Yes"/>
<node CREATED="1486387395674" ID="ID_1720221146" MODIFIED="1486387395674" TEXT="No"/>
<node CREATED="1486387395674" ID="ID_718705556" MODIFIED="1486387395674" TEXT="Not assessable"/>
</node>
</node>
<node BACKGROUND_COLOR="#ccccff" CREATED="1486377503669" ID="ID_276655029" MODIFIED="1486387461669" POSITION="right" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>Clear</b> [0..1]</p>
</body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="choice"/>
<node CREATED="1486387362593" ID="ID_802914300" MODIFIED="1486387362593" TEXT="Yes"/>
<node CREATED="1486387362593" ID="ID_1267358707" MODIFIED="1486387362593" TEXT="No"/>
<node CREATED="1486387362593" ID="ID_1660114549" MODIFIED="1486387362593" TEXT="Not assessable"/>
<node CREATED="1486387373740" ID="ID_296777259" MODIFIED="1486387373740" TEXT="Not investigated"/>
</node>
</node>
</map>
