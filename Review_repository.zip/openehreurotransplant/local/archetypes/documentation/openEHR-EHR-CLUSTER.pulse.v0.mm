<map version="1.0.1">
<!-- To view this file, download free mind mapping software FreeMind from http://freemind.sourceforge.net -->
<node BACKGROUND_COLOR="#ccccff" CREATED="1486039561553" ID="ID_963386627" MODIFIED="1486040708027">
<richcontent TYPE="NODE"><html><head/><body><p>
<b>Pulse</b></p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="14"/>
<icon BUILTIN="cluster"/>
<node BACKGROUND_COLOR="#ccccff" CREATED="1486039561553" ID="ID_372650014" MODIFIED="1486040750911" POSITION="right" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>Presence</b> [0..1]</p>
</body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="choice"/>
<node CREATED="1486040581350" ID="ID_289181906" MODIFIED="1486040671903" TEXT="Present"/>
<node CREATED="1486040581350" ID="ID_1459416133" MODIFIED="1486040667289" TEXT="Not detected"/>
</node>
<node BACKGROUND_COLOR="#ccccff" CREATED="1486039561553" ID="ID_287695419" MODIFIED="1486040805355" POSITION="right" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>Rate</b> [0..1]</p>
</body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="quantity"/>
</node>
<node BACKGROUND_COLOR="#ccccff" CREATED="1486039561553" ID="ID_687431888" MODIFIED="1486385330434" POSITION="right" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>Regular</b> [0..1]</p>
</body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="choice"/>
<node CREATED="1486040597777" ID="ID_1637726347" MODIFIED="1486040662883" TEXT="Regular"/>
<node CREATED="1486040597777" ID="ID_1226962407" MODIFIED="1486040654400" TEXT="Irregular"/>
</node>
<node BACKGROUND_COLOR="#ccccff" CREATED="1486039561553" ID="ID_1179359383" MODIFIED="1486040763068" POSITION="right" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>Irregular type</b> [0..1]</p>
</body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="choice"/>
<icon BUILTIN="text"/>
<node CREATED="1486040610830" ID="ID_884374879" MODIFIED="1486040647021" TEXT="Regularly Irregular"/>
<node CREATED="1486040610830" ID="ID_322017399" MODIFIED="1486040639320" TEXT="Irregularly Irregular"/>
</node>
<node BACKGROUND_COLOR="#ccccff" CREATED="1486039561553" ID="ID_719302130" MODIFIED="1486040774577" POSITION="right" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>Character</b> [0..1]</p>
</body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="text"/>
</node>
<node BACKGROUND_COLOR="#ccccff" CREATED="1486039561553" ID="ID_82735327" MODIFIED="1486040778441" POSITION="right" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>Clinical description</b> [0..1]</p>
</body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="text"/>
</node>
<node BACKGROUND_COLOR="#ccccff" CREATED="1486039561553" ID="ID_1274194928" MODIFIED="1486040791292" POSITION="right" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>Comment</b> [0..1]</p>
</body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="text"/>
</node>
</node>
</map>
