<map version="1.0.1">
<!-- To view this file, download free mind mapping software FreeMind from http://freemind.sourceforge.net -->
<node BACKGROUND_COLOR="#ccccff" CREATED="1486039842846" ID="ID_1769270057" MODIFIED="1486546876993">
<richcontent TYPE="NODE"><html><head/><body><p>
<b>Valve condition</b></p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="14"/>
<icon BUILTIN="cluster"/>
<node BACKGROUND_COLOR="#ccccff" CREATED="1486039842846" ID="ID_1001104482" MODIFIED="1486547857902" POSITION="left" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Condition [1..*]
    </p>
  </body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="cluster"/>
<node BACKGROUND_COLOR="#ccccff" CREATED="1486039842846" ID="ID_266743198" MODIFIED="1486547509250" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      <b>Morphology</b>&#160;[0..1]
    </p>
  </body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="cluster"/>
<node BACKGROUND_COLOR="#ccccff" CREATED="1486039842846" ID="ID_664367075" MODIFIED="1486040526511" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>Morphology</b> [0..1]</p>
</body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="choice"/>
<node CREATED="1486040271141" ID="ID_1284427867" MODIFIED="1486040369611" TEXT="Not assessable"/>
<node CREATED="1486040271141" ID="ID_409008389" MODIFIED="1486040376444" TEXT="Normal"/>
<node CREATED="1486040271141" ID="ID_1935454422" MODIFIED="1486040380569" TEXT="Thickened"/>
<node CREATED="1486040271141" ID="ID_1864841662" MODIFIED="1486040384776" TEXT="Calcification"/>
<node CREATED="1486040107238" ID="ID_634130421" MODIFIED="1486040107238" TEXT="Not investigated"/>
</node>
<node BACKGROUND_COLOR="#ccccff" CREATED="1486039842846" ID="ID_1060709433" MODIFIED="1486040436990" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>Mitral location</b> [0..1]</p>
</body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="cluster"/>
<node BACKGROUND_COLOR="#ccccff" CREATED="1486039842846" ID="ID_1678909094" MODIFIED="1486040523687" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>Posterior valve leaflet</b> [0..1]</p>
</body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="choice"/>
<node CREATED="1486040282927" ID="ID_788064441" MODIFIED="1486040389290" TEXT="Not assessable"/>
<node CREATED="1486040282927" ID="ID_408539341" MODIFIED="1486040393616" TEXT="Normal"/>
<node CREATED="1486040282927" ID="ID_1902162555" MODIFIED="1486040397661" TEXT="Thickened"/>
<node CREATED="1486040282927" ID="ID_511674918" MODIFIED="1486040403920" TEXT="Calcification"/>
</node>
<node BACKGROUND_COLOR="#ccccff" CREATED="1486039842846" ID="ID_60909050" MODIFIED="1486040514772" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>Anterior valve leaflet</b> [0..1]</p>
</body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="choice"/>
<node CREATED="1486040292400" ID="ID_416007698" MODIFIED="1486040408261" TEXT="Not assessable"/>
<node CREATED="1486040292400" ID="ID_1052082466" MODIFIED="1486040412428" TEXT="Normal"/>
<node CREATED="1486040292400" ID="ID_1567171486" MODIFIED="1486040417815" TEXT="Thickened"/>
<node CREATED="1486040292400" ID="ID_1536549268" MODIFIED="1486040422186" TEXT="Calcification"/>
</node>
</node>
</node>
<node BACKGROUND_COLOR="#ccccff" CREATED="1486039842846" ID="ID_34966923" MODIFIED="1486040529259" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>Stenosis</b> [0..1]</p>
</body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="choice"/>
<node CREATED="1486040254002" ID="ID_543444768" MODIFIED="1486040342655" TEXT="Not assessable"/>
<node CREATED="1486040254002" ID="ID_795019112" MODIFIED="1486040348732" TEXT="None"/>
<node CREATED="1486040254002" ID="ID_1257685295" MODIFIED="1486040354663" TEXT="Mild"/>
<node CREATED="1486040254002" ID="ID_259244717" MODIFIED="1486040359867" TEXT="Moderate"/>
<node CREATED="1486040254002" ID="ID_1216538901" MODIFIED="1486040364659" TEXT="Severe"/>
<node CREATED="1486040110027" ID="ID_1201116716" MODIFIED="1486040110027" TEXT="Not investigated"/>
</node>
<node BACKGROUND_COLOR="#ccccff" CREATED="1486039842846" ID="ID_1726130563" MODIFIED="1486547443133" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>Insufficiency</b> [0..1]</p>
</body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="choice"/>
<node CREATED="1486040228676" ID="ID_1536460736" MODIFIED="1486040320619" TEXT="Not assessable        "/>
<node CREATED="1486040228676" ID="ID_1655200155" MODIFIED="1486040325495" TEXT="1"/>
<node CREATED="1486040228676" ID="ID_420779183" MODIFIED="1486040329138" TEXT="2"/>
<node CREATED="1486040228676" ID="ID_1484614112" MODIFIED="1486040336796" TEXT="3 "/>
<node CREATED="1486040112459" ID="ID_1205488804" MODIFIED="1486040112459" TEXT="Not investigated"/>
</node>
</node>
<node BACKGROUND_COLOR="#ccccff" CREATED="1486377546896" ID="ID_57726103" MODIFIED="1486547017337" POSITION="right" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      <b>Valve</b>&#160;[1..1]
    </p>
  </body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="choice"/>
<node CREATED="1486381979182" MODIFIED="1486381979182" TEXT="tricuspid valve"/>
<node CREATED="1486381979183" MODIFIED="1486381979183" TEXT="aortic valve"/>
<node CREATED="1486381979184" MODIFIED="1486381979184" TEXT="mitral valve"/>
<node CREATED="1486381979185" MODIFIED="1486381979185" TEXT="pulmonary valve"/>
</node>
</node>
</map>
