<map version="1.0.1">
<!-- To view this file, download free mind mapping software FreeMind from http://freemind.sourceforge.net -->
<node BACKGROUND_COLOR="#ccccff" CREATED="1505974943427" ID="ID_757008928" MODIFIED="1505974960846">
<richcontent TYPE="NODE"><html><head/><body><p>
<b>Total lung capacity</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      unknown
    </p>
  </body>
</html>
</richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="14"/>
<icon BUILTIN="obs"/>
<node CREATED="1505974943427" FOLDED="true" ID="DESCRIPTION" MODIFIED="1505974943427" POSITION="left" TEXT="DESCRIPTION">
<icon BUILTIN="pencil"/>
<node CREATED="1505974943427" MODIFIED="1505974943427" TEXT="original_author">
<node CREATED="1505974943427" MODIFIED="1505974943427" TEXT="name: "/>
</node>
<node CREATED="1505974943427" MODIFIED="1505974943427" TEXT="lifecycle_state: 0"/>
<node CREATED="1505974943427" MODIFIED="1505974943427" TEXT="purpose: To record the Total Lung Capacity of a person."/>
<node CREATED="1505974943427" MODIFIED="1505974943427" TEXT="use: Use to record the Total Lung Capacity of both adults and children.   Formula  Total Lung Capacity = Inspiratory Reserve Volume (IRV)(Liters) + Tidal Volume(TV) + Expiratory Reserve Volum (liters)+Residual Volume (RV)(Liters) "/>
<node CREATED="1505974943427" MODIFIED="1505974943427" TEXT="other_details">
<node CREATED="1505974943427" MODIFIED="1505974943427" TEXT="MD5-CAM-1.0.1: FF93C24A6E7873CAB6D2C665F58B1D12"/>
</node>
</node>
<node BACKGROUND_COLOR="#ccccff" CREATED="1505974943427" ID="ID_110676593" MODIFIED="1505975143218" POSITION="right" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      <b>Data</b>&#160;[0..1]
    </p>
  </body>
</html>
</richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

<p><b>Tree</b>
</p>
<p><i>@ internal @</i>
</p>
<p>

<span> Type: <b>ITEM_TREE</b></span>
</p>
<p align="left"> Occurences: 0..1 (optional)
</p>
</body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="cluster"/>
<node BACKGROUND_COLOR="#ccccff" CREATED="1505974943427" ID="ID_1168153856" MODIFIED="1505975238406" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>Total lung capacity</b> [0..1]</p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

<p><b>Total lung capacity</b>
</p>
<p><i>*</i>
</p>
<p>

<span> Type: <b>ELEMENT</b></span>
</p>
<p align="left"> Occurences: 0..1 (optional)
</p>
</body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="quantity"/>
</node>
<node BACKGROUND_COLOR="#ccccff" CREATED="1505974943427" ID="ID_378189222" MODIFIED="1505975294731" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>Clinical interpretation</b> [0..1]</p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      <b>Clinical interpretation</b>
    </p>
    <p>
      <i>Single word, phrase or brief description that represents the clinical meaning and significance of the total lung capacity</i>
    </p>
    <p>
      Type: <b>ELEMENT</b>
    </p>
    <p align="left">
      Occurences: 0..1 (optional)
    </p>
  </body>
</html>
</richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="text"/>
</node>
<node BACKGROUND_COLOR="#ccccff" CREATED="1505974943428" ID="ID_273553282" MODIFIED="1505975291291" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>Comment</b> [0..1]</p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      <b>Comment</b>
    </p>
    <p>
      <i>*</i>
    </p>
    <p>
      Type: <b>ELEMENT</b>
    </p>
    <p align="left">
      Occurences: 0..1 (optional)
    </p>
  </body>
</html>
</richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="text"/>
</node>
</node>
<node BACKGROUND_COLOR="#ccccff" CREATED="1505974943428" ID="ID_177595652" MODIFIED="1505975156807" POSITION="right" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      <b>Protocol</b>&#160;[0..1]
    </p>
  </body>
</html>
</richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

<p><b>Tree</b>
</p>
<p><i>@ internal @</i>
</p>
<p>

<span> Type: <b>ITEM_TREE</b></span>
</p>
<p align="left"> Occurences: 0..1 (optional)
</p>
</body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="cluster"/>
<node BACKGROUND_COLOR="#ccccff" CREATED="1505974943428" ID="ID_91000828" MODIFIED="1505975287475" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>Method</b> [0..1]</p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      <b>Method</b>
    </p>
    <p>
      <i>The method of entering the body mass index.</i>
    </p>
    <p>
      Type: <b>ELEMENT</b>
    </p>
    <p align="left">
      Occurences: 0..1 (optional)
    </p>
  </body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="text"/>
</node>
<node BACKGROUND_COLOR="#ccccff" CREATED="1505974943428" ID="ID_832168095" MODIFIED="1505975271012" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>Formula</b> [0..1]</p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      <b>Formula</b>
    </p>
    <p>
      <i>Formula used to derive the body mass index.</i>
    </p>
    <p>
      Type: <b>ELEMENT</b>
    </p>
    <p align="left">
      Occurences: 0..1 (optional)
    </p>
  </body>
</html>
</richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="text"/>
</node>
<node BACKGROUND_COLOR="#cccccc" CREATED="1505974943428" ID="ID_1373857147" MODIFIED="1505975282667" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      <b>Extension</b>
    </p>
  </body>
</html>
</richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

<p align="left">Additional information required to capture local context or to align with other reference models/formalisms.</p>


<p align="left"> Occurences {0..*} </p>


<p align="left">
<p>includes:</p>
<p>archetype_id/value matches {/.*/}</p>
</p>
</body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="slot"/>
</node>
</node>
</node>
</map>
