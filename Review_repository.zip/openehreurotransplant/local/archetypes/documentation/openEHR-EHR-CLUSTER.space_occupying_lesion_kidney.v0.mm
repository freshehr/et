<map version="1.0.1">
<!-- To view this file, download free mind mapping software FreeMind from http://freemind.sourceforge.net -->
<node BACKGROUND_COLOR="#ccccff" CREATED="1508155646570" ID="ID_1391829358" MODIFIED="1508155734575">
<richcontent TYPE="NODE"><html><head/><body><p>
<b>Space occupying lesion kidney</b></p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="14"/>
<icon BUILTIN="cluster"/>
<node BACKGROUND_COLOR="#ccccff" CREATED="1508155646570" ID="ID_1157019966" MODIFIED="1508155725338" POSITION="right" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>Location</b> [0..1]</p>
</body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="choice"/>
<node CREATED="1508155737156" ID="ID_1989884286" MODIFIED="1508155771743" TEXT="Upper pole"/>
<node CREATED="1508155740709" ID="ID_1747842582" MODIFIED="1508155779462" TEXT="Middle section"/>
<node CREATED="1508155744748" ID="ID_1964484567" MODIFIED="1508155799591" TEXT="Lower pole"/>
<node CREATED="1508155746732" ID="ID_1510373151" MODIFIED="1508155810593" TEXT="Multiple locations"/>
</node>
<node BACKGROUND_COLOR="#ccccff" CREATED="1508155646570" ID="ID_682469031" MODIFIED="1508155708422" POSITION="right" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>Comment</b> [0..1]</p>
</body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="text"/>
</node>
</node>
</map>
