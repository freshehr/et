<map version="1.0.1">
<!-- To view this file, download free mind mapping software FreeMind from http://freemind.sourceforge.net -->
<node BACKGROUND_COLOR="#ccccff" CREATED="1498116395010" ID="ID_926736799" MODIFIED="1498116589446">
<richcontent TYPE="NODE"><html><head/><body><p>
<b>Immunological Cumulative Antibodies</b></p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="14"/>
<icon BUILTIN="cluster"/>
<node BACKGROUND_COLOR="#ccccff" CREATED="1498116395010" ID="ID_1420842728" MODIFIED="1498116572505" POSITION="right" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      <b>Cumulative Antibodies</b>&#160;[1..1]
    </p>
  </body>
</html>
</richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="cluster"/>
<node BACKGROUND_COLOR="#cccccc" CREATED="1498116395011" ID="ID_617879917" MODIFIED="1498116529417" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      <b>Antigen</b>
    </p>
  </body>
</html>
</richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="slot_cluster"/>
</node>
</node>
</node>
</map>
