<map version="1.0.1">
<!-- To view this file, download free mind mapping software FreeMind from http://freemind.sourceforge.net -->
<node BACKGROUND_COLOR="#ccccff" CREATED="1508152578677" ID="ID_1524650194" MODIFIED="1508153047670">
<richcontent TYPE="NODE"><html><head/><body><p>
<b>Space occupying lesion</b></p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="14"/>
<icon BUILTIN="cluster"/>
<node BACKGROUND_COLOR="#ccccff" CREATED="1508152578677" ID="ID_1327664354" MODIFIED="1508153001449" POSITION="right" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>Space Occupying Lesion</b> [0..1]</p>
</body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="choice"/>
<node CREATED="1508152870940" ID="ID_490319754" MODIFIED="1508152887838" TEXT="Yes"/>
<node CREATED="1508152875309" ID="ID_838351870" MODIFIED="1508152890670" TEXT="No"/>
<node CREATED="1508152878135" ID="ID_513043556" MODIFIED="1508152899129" TEXT="Not assessable"/>
<node CREATED="1508152881392" ID="ID_1341002551" MODIFIED="1508152906717" TEXT="Not investigated"/>
</node>
<node BACKGROUND_COLOR="#ccccff" CREATED="1508152578678" ID="ID_1384064494" MODIFIED="1508153012013" POSITION="right" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>Lesion Type</b> [0..1]</p>
</body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="choice"/>
<node CREATED="1508152914318" ID="ID_872321588" MODIFIED="1508152935089" TEXT="Tumor"/>
<node CREATED="1508152916760" ID="ID_149032431" MODIFIED="1508152942879" TEXT="Abscess"/>
<node CREATED="1508152977539" ID="ID_10686878" MODIFIED="1508152984865" TEXT="Angioma"/>
<node CREATED="1508152919746" ID="ID_1929966734" MODIFIED="1508152948369" TEXT="Contusion"/>
<node CREATED="1508152921819" ID="ID_891836722" MODIFIED="1508152953555" TEXT="Cyst"/>
<node CREATED="1508152924147" ID="ID_646910496" MODIFIED="1508152961310" TEXT="Not assessable"/>
<node CREATED="1508152928149" ID="ID_1432060991" MODIFIED="1508152967176" TEXT="Unspecified"/>
</node>
<node BACKGROUND_COLOR="#cccccc" CREATED="1508152578678" ID="ID_1445807537" MODIFIED="1508153035015" POSITION="right" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      <b>Location</b>
    </p>
  </body>
</html>
</richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="slot_cluster"/>
</node>
<node BACKGROUND_COLOR="#ccccff" CREATED="1508152578678" ID="ID_481107682" MODIFIED="1508153041854" POSITION="right" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>Remark</b> [0..1]</p>
</body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="text"/>
</node>
</node>
</map>
