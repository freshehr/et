<map version="0.9.0">
<!-- Freemind mindmap generated with LinkEHR editor (www.linkehr.com) on Mon Oct 16 13:49:24 CEST 2017 -->
<node BACKGROUND_COLOR="#ccccff" CREATED="1508154564476" MODIFIED="1508154564476" POSITION="right">
<richcontent TYPE="NODE"><html><head/><body><p>
<b>Space occupying lesion gall bladder and bile duct</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

<p>Location of the space occupying lesion in the Gall bladder and/or Bile duct</p>
</body></html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="14"/>
<icon BUILTIN="cluster"/>
<node CREATED="1508154564477" FOLDED="true" ID="DESCRIPTION" MODIFIED="1508154564477" TEXT="DESCRIPTION" POSITION="left">
<icon BUILTIN="pencil"/>
<node CREATED="1508154564477" MODIFIED="1508154564477" TEXT="original_author">
<node CREATED="1508154564477" MODIFIED="1508154564477" TEXT="name: "/>
</node>
<node CREATED="1508154564477" MODIFIED="1508154564477" TEXT="lifecycle_state: 0"/>
<node CREATED="1508154564477" MODIFIED="1508154564477" TEXT="purpose: To define the location of the space occupying lesion of the gall bladder and/or bile duct."/>
<node CREATED="1508154564477" MODIFIED="1508154564477" TEXT="other_details">
<node CREATED="1508154564477" MODIFIED="1508154564477" TEXT="MD5-CAM-1.0.1: 8B9DC9DE3548F3B7CF1B58F36557ED8D"/>
</node>
</node>
<node CREATED="1508154564477" MODIFIED="1508154564477" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>Comment</b> [0..1]</p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

<p><b>Comment</b>&#xa;</p>
<p><i>Comment on Location of the sol in the gall bladder and bile duct</i>&#xa;</p>
<p>&#xa;&#xa;<span> Type: <b>ELEMENT</b></span>&#xa;</p>
<p align="left"> Occurences: 0..1 (optional)&#xa;</p>
</body>
</html></richcontent>
<icon BUILTIN="elemento"/>
<node CREATED="1508154564477" MODIFIED="1508154564477" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>DV_TEXT</b> [0..1]</p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

<p><b>DV_TEXT</b>&#xa;</p>
<p>&#xa;&#xa;<span> Type: <b>DV_TEXT</b></span>&#xa;</p>
<p align="left"> Occurences: 0..1 (optional)&#xa;</p>
</body>
</html></richcontent>
<icon BUILTIN="textfield"/>
</node>
</node>
</node>
</map>
