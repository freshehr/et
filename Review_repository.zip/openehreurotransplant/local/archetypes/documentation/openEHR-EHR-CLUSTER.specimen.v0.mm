<map version="1.0.1">
<!-- To view this file, download free mind mapping software FreeMind from http://freemind.sourceforge.net -->
<node BACKGROUND_COLOR="#ccccff" CREATED="1490608255354" ID="ID_1391250569" MODIFIED="1490609770843">
<richcontent TYPE="NODE"><html><head/><body><p>
<b>Specimen</b></p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="14"/>
<icon BUILTIN="cluster"/>
<node BACKGROUND_COLOR="#ccccff" CREATED="1490608255355" ID="ID_876664402" MODIFIED="1490609687483" POSITION="right" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>Specimen type</b> [0..1]</p>
</body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="text"/>
</node>
<node BACKGROUND_COLOR="#ccccff" CREATED="1490608255356" ID="ID_1006444209" MODIFIED="1490609733686" POSITION="right" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>Datetime collected</b> [0..1]</p>
</body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="text"/>
</node>
<node BACKGROUND_COLOR="#ccccff" CREATED="1490608255356" ID="ID_1250278089" MODIFIED="1490609757108" POSITION="right" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>Sampling conditions</b> [0..*]</p>
</body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="text"/>
</node>
<node BACKGROUND_COLOR="#cccccc" CREATED="1490608255356" ID="ID_1585586075" MODIFIED="1490609802559" POSITION="right" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      <b>Source site</b>
    </p>
  </body>
</html>
</richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="slot"/>
</node>
<node BACKGROUND_COLOR="#cccccc" CREATED="1490608255356" ID="ID_1498874957" MODIFIED="1490609839815" POSITION="right" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      <b>Physical properties</b>
    </p>
  </body>
</html>
</richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="slot"/>
</node>
<node BACKGROUND_COLOR="#ccccff" CREATED="1490608255356" ID="ID_587240101" MODIFIED="1490609864692" POSITION="right" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>Collection method description</b> [0..1]</p>
</body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="text"/>
</node>
<node BACKGROUND_COLOR="#cccccc" CREATED="1490608255357" ID="ID_1729381526" MODIFIED="1490609898568" POSITION="right" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      <b>Additional collection details</b>
    </p>
  </body>
</html>
</richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="slot"/>
</node>
<node BACKGROUND_COLOR="#ccccff" CREATED="1490608255357" ID="ID_770454485" MODIFIED="1490610150823" POSITION="right" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>Potential risk</b> [0..1]</p>
</body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="text"/>
</node>
<node BACKGROUND_COLOR="#ccccff" CREATED="1490608255357" ID="ID_1629450121" MODIFIED="1490610164326" POSITION="right" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>Collection setting</b> [0..1]</p>
</body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="text"/>
</node>
<node BACKGROUND_COLOR="#ccccff" CREATED="1490608255357" ID="ID_790588913" MODIFIED="1490610178469" POSITION="right" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>Specimen collector identifier</b> [0..1]</p>
</body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="text"/>
</node>
<node BACKGROUND_COLOR="#cccccc" CREATED="1490608255357" ID="ID_1596122978" MODIFIED="1490610199501" POSITION="right" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      <b>Specimen collector details</b>
    </p>
  </body>
</html>
</richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="slot"/>
</node>
<node BACKGROUND_COLOR="#ccccff" CREATED="1490608255357" ID="ID_794463432" MODIFIED="1490610214531" POSITION="right" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>Number of containers</b> [0..1]</p>
</body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="text"/>
</node>
<node BACKGROUND_COLOR="#cccccc" CREATED="1490608255358" ID="ID_1782737446" MODIFIED="1490610257348" POSITION="right" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      <b>Container details</b>
    </p>
  </body>
</html>
</richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="slot"/>
</node>
<node BACKGROUND_COLOR="#ccccff" CREATED="1490608255358" ID="ID_1963073959" MODIFIED="1490610712525" POSITION="right" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>Specimen quality</b> [0..1]</p>
</body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="cluster"/>
<node BACKGROUND_COLOR="#ccccff" CREATED="1490608255358" ID="ID_658882544" MODIFIED="1490610419303" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>Specimen received issues</b> [0..*]</p>
</body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="text"/>
</node>
<node BACKGROUND_COLOR="#ccccff" CREATED="1490608255358" ID="ID_1526321505" MODIFIED="1490610431647" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>Laboratory handling issues</b> [0..*]</p>
</body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="text"/>
</node>
<node BACKGROUND_COLOR="#ccccff" CREATED="1490608255358" ID="ID_968442270" MODIFIED="1490610457885" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>Adequacy for testing</b> [0..1]</p>
</body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="text"/>
</node>
<node BACKGROUND_COLOR="#ccccff" CREATED="1490608255358" ID="ID_490080040" MODIFIED="1490610472851" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>Comment</b> [0..1]</p>
</body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="text"/>
</node>
</node>
<node BACKGROUND_COLOR="#ccccff" CREATED="1490608255358" ID="ID_496894595" MODIFIED="1490610719692" POSITION="right" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>Processing</b> [0..1]</p>
</body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="cluster"/>
<node BACKGROUND_COLOR="#ccccff" CREATED="1490608255358" ID="ID_1038907944" MODIFIED="1490610655842" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>Datetime received</b> [0..1]</p>
</body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="text"/>
</node>
<node BACKGROUND_COLOR="#ccccff" CREATED="1490608255358" ID="ID_1200771735" MODIFIED="1490610681235" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>Laboratory specimen identifier</b> [0..1]</p>
</body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="text"/>
</node>
<node BACKGROUND_COLOR="#cccccc" CREATED="1490608255358" ID="ID_839852486" MODIFIED="1490610704144" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      <b>Processing details</b>
    </p>
  </body>
</html>
</richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="slot"/>
</node>
</node>
<node BACKGROUND_COLOR="#ccccff" CREATED="1490608255359" ID="ID_1060644596" MODIFIED="1490610749645" POSITION="right" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>Related specimen</b> [0..*]</p>
</body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="cluster"/>
<node BACKGROUND_COLOR="#ccccff" CREATED="1490608255359" ID="ID_42101423" MODIFIED="1490610743009" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>Parent specimen identifier</b> [0..1]</p>
</body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="text"/>
</node>
</node>
</node>
</map>
