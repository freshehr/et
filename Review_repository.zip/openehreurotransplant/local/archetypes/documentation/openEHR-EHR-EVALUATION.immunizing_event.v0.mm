<map version="0.9.0">
<!-- Freemind mindmap generated with LinkEHR editor (www.linkehr.com) on Wed Mar 15 13:46:29 CET 2017 -->
<node BACKGROUND_COLOR="#ccccff" CREATED="1489581989240" MODIFIED="1489581989240" POSITION="right">
<richcontent TYPE="NODE"><html><head/><body><p>
<b>Immunizing event</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

<p>unknown</p>
</body></html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="14"/>
<icon BUILTIN="view-refresh"/>
<node CREATED="1489581989240" FOLDED="true" ID="DESCRIPTION" MODIFIED="1489581989240" TEXT="DESCRIPTION" POSITION="left">
<icon BUILTIN="pencil"/>
<node CREATED="1489581989240" MODIFIED="1489581989240" TEXT="original_author">
<node CREATED="1489581989240" MODIFIED="1489581989240" TEXT="name: "/>
</node>
<node CREATED="1489581989240" MODIFIED="1489581989240" TEXT="lifecycle_state: 0"/>
<node CREATED="1489581989240" MODIFIED="1489581989240" TEXT="purpose: "/>
<node CREATED="1489581989240" MODIFIED="1489581989240" TEXT="other_details">
<node CREATED="1489581989240" MODIFIED="1489581989240" TEXT="MD5-CAM-1.0.1: CEAE7002622E8F52CA4C20A03E16091E"/>
</node>
</node>
<node CREATED="1489581989240" MODIFIED="1489581989240" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>Tree</b> [0..1]</p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

<p><b>Tree</b>&#xa;</p>
<p><i>@ internal @</i>&#xa;</p>
<p>&#xa;&#xa;<span> Type: <b>ITEM_TREE</b></span>&#xa;</p>
<p align="left"> Occurences: 0..1 (optional)&#xa;</p>
</body>
</html></richcontent>
<icon BUILTIN="cluster"/>
<node CREATED="1489581989240" MODIFIED="1489581989240" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>Pregnancies</b> [0..1]</p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

<p><b>Pregnancies</b>&#xa;</p>
<p><i>To indicate if the patient has been at anytime in the past or is pregnant. Also including terminated pregnancies. </i>&#xa;</p>
<p>&#xa;&#xa;<span> Type: <b>ELEMENT</b></span>&#xa;</p>
<p align="left"> Occurences: 0..1 (optional)&#xa;</p>
</body>
</html></richcontent>
<icon BUILTIN="elemento"/>
<node CREATED="1489581989240" MODIFIED="1489581989240" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>DV_CODED_TEXT</b> [0..1]</p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

<p><b>DV_CODED_TEXT</b>&#xa;</p>
<p>&#xa;&#xa;<span> Type: <b>DV_CODED_TEXT</b></span>&#xa;</p>
<p align="left"> Occurences: 0..1 (optional)&#xa;</p>
</body>
</html></richcontent>
<icon BUILTIN="tag_red"/>
</node>
</node>
<node CREATED="1489581989240" MODIFIED="1489581989240" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>Blood Transfusions</b> [0..1]</p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

<p><b>Blood Transfusions</b>&#xa;</p>
<p><i>Has had blood transfusions at any time in the past.</i>&#xa;</p>
<p>&#xa;&#xa;<span> Type: <b>ELEMENT</b></span>&#xa;</p>
<p align="left"> Occurences: 0..1 (optional)&#xa;</p>
</body>
</html></richcontent>
<icon BUILTIN="elemento"/>
<node CREATED="1489581989241" MODIFIED="1489581989241" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>DV_CODED_TEXT</b> [0..1]</p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

<p><b>DV_CODED_TEXT</b>&#xa;</p>
<p>&#xa;&#xa;<span> Type: <b>DV_CODED_TEXT</b></span>&#xa;</p>
<p align="left"> Occurences: 0..1 (optional)&#xa;</p>
</body>
</html></richcontent>
<icon BUILTIN="tag_red"/>
</node>
</node>
</node>
</node>
</map>
