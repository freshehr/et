<map version="1.0.1">
<!-- To view this file, download free mind mapping software FreeMind from http://freemind.sourceforge.net -->
<node BACKGROUND_COLOR="#ccccff" CREATED="1486039797871" ID="ID_633928331" MODIFIED="1486046302752">
<richcontent TYPE="NODE"><html><head/><body><p>
<b>Ecg narrative</b></p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="14"/>
<icon BUILTIN="cluster"/>
<node BACKGROUND_COLOR="#ccccff" CREATED="1486039797871" ID="ID_1033630179" MODIFIED="1486046312816" POSITION="right" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>ECG plot at ET</b> [0..1]</p>
</body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="choice"/>
<node CREATED="1486045958255" ID="ID_175268902" MODIFIED="1486045958255" TEXT="Yes"/>
<node CREATED="1486045958256" ID="ID_146731351" MODIFIED="1486045958256" TEXT="No"/>
</node>
<node BACKGROUND_COLOR="#ccccff" CREATED="1486039797871" ID="ID_695739595" MODIFIED="1486046425908" POSITION="right" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>Heart rate (Digits BPM)</b> [0..1]</p>
</body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="count"/>
</node>
<node BACKGROUND_COLOR="#ccccff" CREATED="1486039797871" ID="ID_1395665288" MODIFIED="1486046320654" POSITION="right" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>Sinus-Rhythmus</b> [0..1]</p>
</body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="choice"/>
<node CREATED="1486045966818" ID="ID_871355668" MODIFIED="1486045966818" TEXT="Yes"/>
<node CREATED="1486045966819" ID="ID_677254613" MODIFIED="1486045966819" TEXT="No"/>
</node>
<node BACKGROUND_COLOR="#ccccff" CREATED="1486039797871" ID="ID_1071276927" MODIFIED="1486046323952" POSITION="right" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>AV-Blok</b> [0..1]</p>
</body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="choice"/>
<node CREATED="1486045980626" ID="ID_10671112" MODIFIED="1486045980626" TEXT="Yes"/>
<node CREATED="1486045980627" ID="ID_702642380" MODIFIED="1486045980627" TEXT="None"/>
</node>
<node BACKGROUND_COLOR="#ccccff" CREATED="1486039797871" ID="ID_135667559" MODIFIED="1486046327344" POSITION="right" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>Atrial Arrythmia</b> [0..1]</p>
</body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="choice"/>
<node CREATED="1486045986954" ID="ID_1220109892" MODIFIED="1486045986954" TEXT="Yes"/>
<node CREATED="1486045986955" ID="ID_1646310372" MODIFIED="1486045986955" TEXT="None"/>
</node>
<node BACKGROUND_COLOR="#ccccff" CREATED="1486039797871" ID="ID_283929180" MODIFIED="1486046330496" POSITION="right" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>Ventricular Arrythmia</b> [0..1]</p>
</body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="choice"/>
<node CREATED="1486045990906" ID="ID_258034465" MODIFIED="1486045990906" TEXT="Yes"/>
<node CREATED="1486045990907" ID="ID_1056698447" MODIFIED="1486045990907" TEXT="None"/>
</node>
<node BACKGROUND_COLOR="#ccccff" CREATED="1486039797872" ID="ID_334519252" MODIFIED="1486046403976" POSITION="right" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>Comment</b> [0..1]</p>
</body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="text"/>
</node>
<node BACKGROUND_COLOR="#ccccff" CREATED="1486039797872" ID="ID_1709862230" MODIFIED="1486046336800" POSITION="right" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>QRS changes</b> [0..1]</p>
</body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="choice"/>
<node CREATED="1486046001978" ID="ID_1539647479" MODIFIED="1486046001978" TEXT="None"/>
<node CREATED="1486046001979" ID="ID_1854368313" MODIFIED="1486046001979" TEXT="Left bundle block"/>
<node CREATED="1486046001980" ID="ID_1969004633" MODIFIED="1486046001980" TEXT="Bifsc. block"/>
<node CREATED="1486046001980" ID="ID_96732343" MODIFIED="1486046001980" TEXT="Infart like"/>
<node CREATED="1486046001981" ID="ID_587757218" MODIFIED="1486046001981" TEXT="Right bundle block"/>
<node CREATED="1486046001981" ID="ID_205873067" MODIFIED="1486046001981" TEXT="Other"/>
<node CREATED="1486046001982" ID="ID_38311114" MODIFIED="1486046001982" TEXT="Not assessable"/>
<node CREATED="1486046013865" ID="ID_1704101350" MODIFIED="1486046013865" TEXT="Not investigated"/>
</node>
<node BACKGROUND_COLOR="#ccccff" CREATED="1486039797872" ID="ID_15432746" MODIFIED="1486046351032" POSITION="right" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>STT segment changes</b> [0..1]</p>
</body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="choice"/>
<node CREATED="1486046083282" ID="ID_1513157597" MODIFIED="1486046083282" TEXT="None"/>
<node CREATED="1486046083282" ID="ID_1417543347" MODIFIED="1486046083282" TEXT="Yes"/>
<node CREATED="1486046083283" ID="ID_1584709430" MODIFIED="1486046083283" TEXT="Not assessable"/>
<node CREATED="1486384146633" ID="ID_1172815654" MODIFIED="1486384150161" TEXT="TEXT"/>
<node CREATED="1486046116056" ID="ID_1500833558" MODIFIED="1486046116056" TEXT="Not investigated"/>
</node>
<node BACKGROUND_COLOR="#ccccff" CREATED="1486039797872" ID="ID_520827192" MODIFIED="1486046380275" POSITION="right" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>QTc-Time classification</b> [0..1]</p>
</body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="choice"/>
<node CREATED="1486046130314" ID="ID_1190002112" MODIFIED="1486046130314" TEXT="Normal"/>
<node CREATED="1486046130315" ID="ID_1740769697" MODIFIED="1486046130315" TEXT="Prolonged"/>
<node CREATED="1486046130316" ID="ID_165213643" MODIFIED="1486046130316" TEXT="Not assessable"/>
<node CREATED="1486046141810" ID="ID_9010349" MODIFIED="1486046141810" TEXT="Not investigated"/>
</node>
<node BACKGROUND_COLOR="#ccccff" CREATED="1486039797872" ID="ID_1676102920" MODIFIED="1486046356448" POSITION="right" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>QTc-Time in ms</b> [0..1]</p>
</body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="quantity"/>
</node>
<node BACKGROUND_COLOR="#ccccff" CREATED="1486039797872" ID="ID_161492833" MODIFIED="1489404187352" POSITION="right" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>LV-Hypertrophy</b> [0..1]</p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      <b>LV-Hypertrophy</b>
    </p>
    <p>
      <i>*</i>
    </p>
    <p>
      Type: <b>ELEMENT</b>
    </p>
    <p align="left">
      Occurences: 0..1 (optional)
    </p>
  </body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="choice"/>
<node CREATED="1486046025202" MODIFIED="1486046025202" TEXT="None"/>
<node CREATED="1486046025202" MODIFIED="1486046025202" TEXT="Yes"/>
<node CREATED="1486046025203" MODIFIED="1486046025203" TEXT="Not assessable"/>
<node CREATED="1486046013865" ID="ID_1640113957" MODIFIED="1486046013865" TEXT="Not investigated"/>
</node>
</node>
</map>
