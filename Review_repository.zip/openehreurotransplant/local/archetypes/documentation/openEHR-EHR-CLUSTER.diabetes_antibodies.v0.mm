<map version="1.0.1">
<!-- To view this file, download free mind mapping software FreeMind from http://freemind.sourceforge.net -->
<node BACKGROUND_COLOR="#ccccff" CREATED="1494914316816" ID="ID_316177046" MODIFIED="1494914442343">
<richcontent TYPE="NODE"><html><head/><body><p>
<b>Diabetes related antibodies</b></p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="14"/>
<icon BUILTIN="cluster"/>
<node BACKGROUND_COLOR="#ccccff" CREATED="1494914316817" ID="ID_1232429185" MODIFIED="1494915029749" POSITION="right" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>IA-2</b> [0..1]</p>
</body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="text"/>
</node>
<node BACKGROUND_COLOR="#ccccff" CREATED="1494914316817" ID="ID_1927356164" MODIFIED="1494915032325" POSITION="right" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>IAA</b> [0..1]</p>
</body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="text"/>
</node>
<node BACKGROUND_COLOR="#ccccff" CREATED="1494914316817" ID="ID_1608334803" MODIFIED="1494915039797" POSITION="right" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>Sample date IAA</b> [0..1]</p>
</body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="datetime"/>
</node>
<node BACKGROUND_COLOR="#ccccff" CREATED="1494914316817" ID="ID_1556855243" MODIFIED="1494915042373" POSITION="right" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>Start Insuline Therapy</b> [0..1]</p>
</body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="datetime"/>
</node>
<node BACKGROUND_COLOR="#ccccff" CREATED="1494914316818" ID="ID_1931630445" MODIFIED="1494915050348" POSITION="right" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>ICA</b> [0..1]</p>
</body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="text"/>
</node>
<node BACKGROUND_COLOR="#ccccff" CREATED="1494914316818" ID="ID_969206355" MODIFIED="1494915053356" POSITION="right" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>GAD</b> [0..1]</p>
</body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="text"/>
</node>
<node BACKGROUND_COLOR="#ccccff" CREATED="1494914316818" ID="ID_241135035" MODIFIED="1494915056252" POSITION="right" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>ZnT8</b> [0..1]</p>
</body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="text"/>
</node>
</node>
</map>
