<map version="1.0.1">
<!-- To view this file, download free mind mapping software FreeMind from http://freemind.sourceforge.net -->
<node BACKGROUND_COLOR="#ccccff" CREATED="1508155068497" ID="ID_1560134662" MODIFIED="1508155096461">
<richcontent TYPE="NODE"><html><head/><body><p>
<b>Space occupying lesion pancreas</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      unknown
    </p>
  </body>
</html>
</richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="14"/>
<icon BUILTIN="cluster"/>
<node BACKGROUND_COLOR="#ccccff" CREATED="1508155068498" ID="ID_367654317" MODIFIED="1508155195057" POSITION="right" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>Location</b> [0..1]</p>
</body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="choice"/>
<node CREATED="1508155128017" ID="ID_1828743074" MODIFIED="1508155184469" TEXT="Head"/>
<node CREATED="1508155130426" ID="ID_1669471429" MODIFIED="1508155188422" TEXT="Tail"/>
<node CREATED="1508155133082" ID="ID_1269101635" MODIFIED="1508155180845" TEXT="Multiple Locations"/>
</node>
<node BACKGROUND_COLOR="#ccccff" CREATED="1508155068498" ID="ID_1125428484" MODIFIED="1508155214297" POSITION="right" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>Comment</b> [0..1]</p>
</body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
</node>
</node>
</map>
