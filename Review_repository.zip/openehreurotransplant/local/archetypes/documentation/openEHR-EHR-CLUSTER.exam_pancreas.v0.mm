<map version="1.0.1">
<!-- To view this file, download free mind mapping software FreeMind from http://freemind.sourceforge.net -->
<node BACKGROUND_COLOR="#ccccff" CREATED="1484565160561" ID="ID_980168868" MODIFIED="1484565577609">
<richcontent TYPE="NODE"><html><head/><body><p>
<b>Exam pancreas</b></p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="14"/>
<icon BUILTIN="cluster"/>
<node BACKGROUND_COLOR="#ccccff" CREATED="1484565160561" ID="ID_1599813710" MODIFIED="1484565583754" POSITION="right" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>Space Occupying Lesion</b> [0..*]</p>
</body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="cluster"/>
<node BACKGROUND_COLOR="#ccccff" CREATED="1484565160561" ID="ID_989248594" MODIFIED="1484565818766" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>Location Of Space Occupying Lesion</b> [0..1]</p>
</body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="choice"/>
<node CREATED="1484565811959" ID="ID_1726498772" MODIFIED="1484565814801" TEXT="Head"/>
<node CREATED="1484565818781" ID="ID_1449211972" MODIFIED="1484565821500" TEXT="Tail"/>
<node CREATED="1484565825642" ID="ID_587529484" MODIFIED="1484565833633" TEXT="Multiple lesions"/>
</node>
<node BACKGROUND_COLOR="#cccccc" CREATED="1484565160561" ID="ID_1565959719" MODIFIED="1484565740816" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      <b>Space Occupying Lesion</b>
    </p>
  </body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="slot_cluster"/>
</node>
</node>
<node BACKGROUND_COLOR="#ccccff" CREATED="1484565160561" ID="ID_544330622" MODIFIED="1484565707270" POSITION="right" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>Signs of pancreatitis</b> [0..1]</p>
</body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="choice"/>
<node CREATED="1484566008298" ID="ID_660827641" MODIFIED="1484566011038" TEXT="Yes"/>
<node CREATED="1484566015127" ID="ID_1419835701" MODIFIED="1484566017410" TEXT="No"/>
<node CREATED="1484566021100" ID="ID_1966009572" MODIFIED="1484566026548" TEXT="Not assessable"/>
<node CREATED="1484565841712" ID="ID_702658143" MODIFIED="1484565850032" TEXT="Not investigated"/>
</node>
<node BACKGROUND_COLOR="#ccccff" CREATED="1484565160561" ID="ID_607101260" MODIFIED="1484566021100" POSITION="right" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>Signs of calcification</b> [0..1]</p>
</body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="choice"/>
<node CREATED="1484566008298" ID="ID_1020165825" MODIFIED="1484566011038" TEXT="Yes"/>
<node CREATED="1484566015127" ID="ID_1698628236" MODIFIED="1484566017410" TEXT="No"/>
<node CREATED="1484566021100" ID="ID_1077271423" MODIFIED="1484566026548" TEXT="Not assessable"/>
<node CREATED="1484565841712" ID="ID_1184253221" MODIFIED="1484565850032" TEXT="Not investigated"/>
</node>
<node BACKGROUND_COLOR="#ccccff" CREATED="1484565160561" ID="ID_242485575" MODIFIED="1484565983379" POSITION="right" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>Parenchyma</b> [0..1]</p>
</body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="choice"/>
<node CREATED="1484565867555" ID="ID_145052619" MODIFIED="1484565955622" TEXT="Lipomatosis"/>
<node CREATED="1484565960993" ID="ID_738152505" MODIFIED="1484565969117" TEXT="Fibrosis"/>
<node CREATED="1484565975017" ID="ID_689374354" MODIFIED="1484565978272" TEXT="Edema"/>
<node CREATED="1484565985706" ID="ID_1530584066" MODIFIED="1484565988944" TEXT="Normal"/>
<node CREATED="1484565994512" ID="ID_347335271" MODIFIED="1484565998681" TEXT="Not assessable"/>
<node CREATED="1484565841712" ID="ID_1836499481" MODIFIED="1484565850032" TEXT="Not investigated"/>
</node>
</node>
</map>
