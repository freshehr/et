<map version="1.0.1">
<!-- To view this file, download free mind mapping software FreeMind from http://freemind.sourceforge.net -->
<node BACKGROUND_COLOR="#ccccff" CREATED="1486377466863" ID="ID_1228454431" MODIFIED="1486387801933">
<richcontent TYPE="NODE"><html><head/><body><p>
<b>Bronchoscopy</b></p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="14"/>
<icon BUILTIN="cluster"/>
<node BACKGROUND_COLOR="#ccccff" CREATED="1486377466863" ID="ID_1891280124" MODIFIED="1486387872904" POSITION="right" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>trachea</b> [0..*]</p>
</body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="cluster"/>
<node BACKGROUND_COLOR="#ccccff" CREATED="1486377466863" ID="ID_1978625009" MODIFIED="1486387869292" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>Epithelium trachea</b> [0..1]</p>
</body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="cluster"/>
<node BACKGROUND_COLOR="#ccccff" CREATED="1486377466863" ID="ID_1976878026" MODIFIED="1486387872898" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>Epithelium trachea</b> [0..1]</p>
</body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="choice"/>
<node CREATED="1486387616820" ID="ID_1192929989" MODIFIED="1486387616820" TEXT="Pathological"/>
<node CREATED="1486387616820" ID="ID_1728414190" MODIFIED="1486387616820" TEXT="Normal"/>
<node CREATED="1486387616820" ID="ID_831657492" MODIFIED="1486387616820" TEXT="Not assessable"/>
</node>
<node BACKGROUND_COLOR="#ccccff" CREATED="1486377466863" ID="ID_1441718794" MODIFIED="1486387862996" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>Comment</b> [0..1]</p>
</body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="text"/>
</node>
</node>
<node BACKGROUND_COLOR="#ccccff" CREATED="1486377466864" ID="ID_1889358405" MODIFIED="1486387859068" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>Pathological abnormalities trachea</b> [0..1]</p>
</body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="choice"/>
<node CREATED="1486387659920" ID="ID_925477725" MODIFIED="1486387659920" TEXT="Inflammation"/>
<node CREATED="1486387659921" ID="ID_243385849" MODIFIED="1486387659921" TEXT="Bleeding"/>
<node CREATED="1486387659922" ID="ID_550175930" MODIFIED="1486387659922" TEXT="Ulceration"/>
<node CREATED="1486387659922" ID="ID_547950524" MODIFIED="1486387659922" TEXT="Tumor"/>
<node CREATED="1486387659922" ID="ID_491977855" MODIFIED="1486387659922" TEXT="Putrid secretions"/>
<node CREATED="1486387659923" ID="ID_668292625" MODIFIED="1486387659923" TEXT="Aspiration"/>
<node CREATED="1486387659923" ID="ID_1632070744" MODIFIED="1486387659923" TEXT="Not assessable"/>
<node CREATED="1486387674022" ID="ID_477853524" MODIFIED="1486387674022" TEXT="Not investigated"/>
</node>
<node BACKGROUND_COLOR="#ccccff" CREATED="1486377466864" ID="ID_1086155275" MODIFIED="1486387855764" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>Comment</b> [0..1]</p>
</body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="text"/>
</node>
</node>
<node BACKGROUND_COLOR="#ccccff" CREATED="1486377466864" ID="ID_1826507223" MODIFIED="1486387847930" POSITION="right" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>Additional bronchus</b> [0..1]</p>
</body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="choice"/>
<node CREATED="1486387722207" ID="ID_728812511" MODIFIED="1486387722207" TEXT="Yes"/>
<node CREATED="1486387722208" ID="ID_1468684182" MODIFIED="1486387722208" TEXT="No"/>
</node>
<node BACKGROUND_COLOR="#cccccc" CREATED="1486377466864" ID="ID_1017897248" MODIFIED="1486387844124" POSITION="right" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      <b>Left bronchus</b>
    </p>
  </body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="slot_cluster"/>
</node>
<node BACKGROUND_COLOR="#cccccc" CREATED="1486377466864" ID="ID_584116720" MODIFIED="1486387839866" POSITION="right" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      <b>Right bronchus</b>
    </p>
  </body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="slot_cluster"/>
</node>
<node BACKGROUND_COLOR="#ccccff" CREATED="1486377466864" ID="ID_1136435794" MODIFIED="1486387834896" POSITION="right" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>Comments</b> [0..1]</p>
</body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="text"/>
</node>
<node BACKGROUND_COLOR="#ccccff" CREATED="1486377466864" ID="ID_677272310" MODIFIED="1486387820812" POSITION="right" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>Microbiology TBA</b> [0..1]</p>
</body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="cluster"/>
<node BACKGROUND_COLOR="#ccccff" CREATED="1486377466864" ID="ID_784393379" MODIFIED="1486387818012" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>Send to lab</b> [0..1]</p>
</body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="choice"/>
<node CREATED="1486387735301" ID="ID_1236274437" MODIFIED="1486387735301" TEXT="Yes"/>
<node CREATED="1486387735301" ID="ID_307307004" MODIFIED="1486387735301" TEXT="No"/>
</node>
</node>
<node BACKGROUND_COLOR="#ccccff" CREATED="1486377466865" ID="ID_272486370" MODIFIED="1486387811028" POSITION="right" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>Microbiology BAL</b> [0..1]</p>
</body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="cluster"/>
<node BACKGROUND_COLOR="#ccccff" CREATED="1486377466865" ID="ID_135691350" MODIFIED="1486387814388" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>Send to lab</b> [0..1]</p>
</body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="choice"/>
<node CREATED="1486387739855" ID="ID_896205510" MODIFIED="1486387739855" TEXT="Yes"/>
<node CREATED="1486387739855" ID="ID_895415074" MODIFIED="1486387739855" TEXT="No"/>
</node>
</node>
</node>
</map>
