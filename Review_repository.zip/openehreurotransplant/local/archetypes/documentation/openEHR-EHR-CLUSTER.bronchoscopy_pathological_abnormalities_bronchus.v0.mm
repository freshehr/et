<map version="1.0.1">
<!-- To view this file, download free mind mapping software FreeMind from http://freemind.sourceforge.net -->
<node BACKGROUND_COLOR="#ccccff" CREATED="1486039812516" ID="ID_1669695737" MODIFIED="1486044620769">
<richcontent TYPE="NODE"><html><head/><body><p>
<b>Pathological abnormalities bronchus</b></p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="14"/>
<icon BUILTIN="cluster"/>
<node BACKGROUND_COLOR="#ccccff" CREATED="1486039812516" ID="ID_1418064225" MODIFIED="1486044628769" POSITION="right" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>Epithelium bronchus</b> [0..1]</p>
</body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="cluster"/>
<node BACKGROUND_COLOR="#ccccff" CREATED="1486039812516" ID="ID_1022916687" MODIFIED="1486044625208" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>Pathological abnormalities bronchus</b> [0..1]</p>
</body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="choice"/>
<node CREATED="1486044453298" MODIFIED="1486044453298" TEXT="Inflammation"/>
<node CREATED="1486044453299" MODIFIED="1486044453299" TEXT="Bleeding"/>
<node CREATED="1486044453299" MODIFIED="1486044453299" TEXT="Ulceration"/>
<node CREATED="1486044453300" MODIFIED="1486044453300" TEXT="Tumor"/>
<node CREATED="1486044453300" MODIFIED="1486044453300" TEXT="Putrid secretions"/>
<node CREATED="1486044453301" MODIFIED="1486044453301" TEXT="Aspiration"/>
</node>
<node BACKGROUND_COLOR="#ccccff" CREATED="1486039812516" ID="ID_522601944" MODIFIED="1486044635657" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>Putrid secretions</b> [0..1]</p>
</body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="cluster"/>
<node BACKGROUND_COLOR="#ccccff" CREATED="1486039812516" ID="ID_1406215777" MODIFIED="1486044632225" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>After suction</b> [0..1]</p>
</body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="choice"/>
<node CREATED="1486044469035" MODIFIED="1486044469035" TEXT="Clean"/>
<node CREATED="1486044469035" MODIFIED="1486044469035" TEXT="Refill (from periphery)"/>
<node CREATED="1486044491362" ID="ID_1921406636" MODIFIED="1486044491362" TEXT="Not investigated"/>
</node>
<node BACKGROUND_COLOR="#ccccff" CREATED="1486039812516" ID="ID_1146222688" MODIFIED="1486044642881" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>Location of secretion</b> [0..1]</p>
</body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="choice"/>
<node CREATED="1486044480484" MODIFIED="1486044480484" TEXT="None"/>
<node CREATED="1486044480485" MODIFIED="1486044480485" TEXT="Main"/>
<node CREATED="1486044480486" MODIFIED="1486044480486" TEXT="Lobar"/>
<node CREATED="1486044480486" MODIFIED="1486044480486" TEXT="Sublobar"/>
</node>
</node>
<node BACKGROUND_COLOR="#ccccff" CREATED="1486039812516" ID="ID_483731179" MODIFIED="1486044646017" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>Epithelium bronchus</b> [0..1]</p>
</body>
</html></richcontent>
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<icon BUILTIN="choice"/>
<node CREATED="1486044508889" MODIFIED="1486044508889" TEXT="Pathological"/>
<node CREATED="1486044508889" MODIFIED="1486044508889" TEXT="Normal"/>
<node CREATED="1486044508889" MODIFIED="1486044508889" TEXT="Not assessable"/>
<node CREATED="1486044518731" ID="ID_1326681666" MODIFIED="1486044518731" TEXT="Not investigated"/>
</node>
</node>
</node>
</map>
